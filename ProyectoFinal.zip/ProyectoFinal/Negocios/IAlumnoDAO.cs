﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios
{
    public interface IAlumnoDAO
    {
        Alumno GetByMatricula(String matricula);
        Alumno GetByNombre(String nombre);
        Alumno GetByApellidoPaterno(String apellidoPaterno);
        Alumno GetByApellidoMaterno(String apellidoMaterno);
        Alumno GetByCorreoElectronico(String correoElectronico);
        Alumno GetByBloque(String bloque);
        Alumno GetBySeccion(String seccion);
        List<Alumno> GetAlumno(String criteria);

    }
}
