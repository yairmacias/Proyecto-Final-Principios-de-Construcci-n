﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios
{
    public interface IOrganizacionDAO
    {
        Organizacion GetByIDOrganizacion(String idOrganizacion);
        Organizacion GetByNombre(String nombre);
        Organizacion GetByCalle(String calle);
        Organizacion GetByMCodigoPostla(String codigoPostal);
        Organizacion GetByColonia(String colonia);
        Organizacion GetByCorreoElectronico(String correoElectronico);
        Organizacion GetByEstado(String estado);
        Organizacion GetNumeroInterno(String numeroInterno);
        Organizacion GetSecotr(String sector);
        Organizacion GetTelefono(String telefono);
        List<Organizacion> GetProyecto(String criteria);
    }
}
