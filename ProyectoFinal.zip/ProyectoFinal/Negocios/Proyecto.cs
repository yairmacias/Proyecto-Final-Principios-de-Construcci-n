﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios
{
    public class Proyecto
    {
        public String IDProyecto { get; set; }
        public String Actividad { get; set; }
        public String Calendarizacion { get; set; }
        public String DescripcionGeneral { get; set; }
        public String Dias { get; set; }
        public String Duracion { get; set; }
        public String Funcion { get; set; }
        public String Hora { get; set; }
        public String Metodologia { get; set; }
        public String Nombre { get; set; }
        public String ObjetivoGeneral { get; set; }
        public String ObjetivoInmediato { get; set; }
        public String ObjetivoMediato { get; set; }
        public String RecursoEconomico { get; set; }
        public String RecursoHumano { get; set; }
        public String RecursoMaterial { get; set; }
        public String Responsabilidad { get; set; }

    }
}
