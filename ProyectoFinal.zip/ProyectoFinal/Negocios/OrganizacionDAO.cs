﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using ConexionBaseDeDatos;

namespace Negocios
{
    public class OrganizacionDAO
    {
        public Organizacion GetByIDOrganizacion(string idOrganizacion)
        {
            Organizacion organizacion = new Organizacion();
            GestionBaseDeDatos dbManager = new GestionBaseDeDatos();
            using (SqlConnection conexion = dbManager.GetConnection())
            {
                conexion.Open();
                using (SqlCommand command = new SqlCommand("Select * from Organizacion where userid=@IDOrganizacion", conexion))
                {
                    command.Parameters.Add(new SqlParameter("IDOrganizacion", idOrganizacion));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        organizacion.Nombre = reader["Nombre"].ToString();
                        organizacion.Calle = reader["Calle"].ToString();
                        organizacion.Ciudad = reader["Ciudad"].ToString();
                        organizacion.CodigoPostal = reader["CodigoPostal"].ToString();
                        organizacion.Colonia = reader["Colonia"].ToString();
                        organizacion.CorreoElectronico = reader["CorreoElectronico"].ToString();
                        organizacion.Estado = reader["Estado"].ToString();
                        organizacion.NumeroInterno = reader["NumeroInterno"].ToString();
                        organizacion.Sector = reader["Sector"].ToString();
                        organizacion.Telefono = reader["Telefono"].ToString();
                    }
                }
                dbManager.CloseConnection();
            }
            return organizacion;
        }
    }
}
