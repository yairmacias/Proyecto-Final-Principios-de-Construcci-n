﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios
{
    public interface IEncargadoDAO
    {
        Encargado GetByIDEncargado(String idEncargado);
        Encargado GetByNombre(String nombre);
        Encargado GetByApellidoPaterno(String apellidoPaterno);
        Encargado GetByApellidoMaterno(String apellidoMaterno);
        Encargado GetByCorreoElectronico(String correoElectronico);
        Encargado GetByTelefono(String telefono);
        List<Encargado> GetEncargado(String criteria);
    }
}
