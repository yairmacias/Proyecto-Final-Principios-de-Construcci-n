﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using ConexionBaseDeDatos;

namespace Negocios
{
    public class EncargadoDAO : IEncargadoDAO
    {
        public Encargado GetByIDEncargado(string idEncargado)
        {
            Encargado encargado = new Encargado();
            GestionBaseDeDatos dbManager = new GestionBaseDeDatos();
            using (SqlConnection conexion = dbManager.GetConnection())
            {
                conexion.Open();
                using (SqlCommand command = new SqlCommand("Select * from Encargado where userid=@IDEncargado", conexion))
                {
                    command.Parameters.Add(new SqlParameter("IDEncargado", idEncargado));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        encargado.Nombre = reader["Nombre"].ToString();
                        encargado.ApellidoPaterno = reader["ApellidoPaterno"].ToString();
                        encargado.ApellidoMaterno = reader["ApellidoMaterno"].ToString();
                        encargado.CorreoElectronico = reader["CorreoElectronico"].ToString();
                        encargado.Telefono = reader["Telefono"].ToString();
                    }
                }
                dbManager.CloseConnection();
            }
            return encargado;
        }
    }
}
