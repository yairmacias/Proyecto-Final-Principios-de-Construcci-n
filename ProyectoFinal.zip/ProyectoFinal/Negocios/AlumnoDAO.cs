﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using ConexionBaseDeDatos;

namespace ProyectoFinal
{
    public class AlumnoDAO 
    {
        public Alumno GetByMatricula(string matricula)
        {
            Alumno alumno = new Alumno();
            GestionBaseDeDatos dbManager = new GestionBaseDeDatos();
            using (SqlConnection conexion = dbManager.GetConnection())
            {
                conexion.Open();
                using (SqlCommand command = new SqlCommand("Select * from Alumno where userid=@matricula", conexion))
                {
                    command.Parameters.Add(new SqlParameter("Matricula", matricula));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        alumno.Nombre = reader["Nombre"].ToString();
                        alumno.ApellidoPaterno = reader["ApellidoPaterno"].ToString();
                        alumno.ApellidoMaterno = reader["ApellidoMaterno"].ToString();
                        alumno.CorreoElectronico = reader["CorreoElectronico"].ToString();
                        alumno.Seccion = reader["Seccion"].ToString();
                        alumno.Bloque = reader["Bloque"].ToString();
                    }
                }
                dbManager.CloseConnection();
            }
            return alumno;
        }

        public void ResgistrarDatosAlumno(Alumno alum)
        {
            Alumno alumno = new Alumno();
            GestionBaseDeDatos dbManager = new GestionBaseDeDatos();
            using (SqlConnection conexion = dbManager.GetConnection())
            {
                conexion.Open();
                using (SqlCommand command = new SqlCommand("Insert into Alumno (@Nombre, @ApellidoPaterno, @ApellidoMaterno, @CorreoElectronico, @Bloque, @Seccion)", conexion))
                {
                
                }
            }
        }

    }
}
