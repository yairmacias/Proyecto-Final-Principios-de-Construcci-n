﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using ConexionBaseDeDatos;

namespace Negocios
{
     class ProyectoDAO
    {
        public Proyecto GetByIDProyecto(string idProyecto)
        {
            Proyecto proyecto = new Proyecto();
            GestionBaseDeDatos dbManager = new GestionBaseDeDatos();
            using (SqlConnection conexion = dbManager.GetConnection())
            {
                conexion.Open();
                using (SqlCommand command = new SqlCommand("Select * from Proyecto where userid=@IDProyecto", conexion))
                {
                    command.Parameters.Add(new SqlParameter("IDProyecto", idProyecto));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        proyecto.Nombre = reader["Nombre"].ToString();
                        proyecto.Actividad = reader["Actividad"].ToString();
                        proyecto.Calendarizacion = reader["Calendarizacion"].ToString();
                        proyecto.DescripcionGeneral = reader["DescripcionGeneral"].ToString();
                        proyecto.Dias = reader["Dias"].ToString();
                        proyecto.Duracion = reader["Duracion"].ToString();
                        proyecto.Funcion = reader["Funcion"].ToString();
                        proyecto.Hora = reader["Hora"].ToString();
                        proyecto.Metodologia = reader["Metodologia"].ToString();
                        proyecto.ObjetivoGeneral = reader["ObjetivoGeneral"].ToString();
                        proyecto.ObjetivoInmediato = reader["ObjetivoInmediaro"].ToString();
                        proyecto.ObjetivoMediato = reader["ObjetivoMediato"].ToString();
                        proyecto.RecursoEconomico = reader["RecursoEconomico"].ToString();
                        proyecto.RecursoHumano = reader["RecursoHumano"].ToString();
                        proyecto.RecursoMaterial = reader["RecursoMaterial"].ToString();
                        proyecto.Responsabilidad = reader["Responsabilidad"].ToString();
                    }
                }
                dbManager.CloseConnection();
            }
            return proyecto;
        }
    }
}
