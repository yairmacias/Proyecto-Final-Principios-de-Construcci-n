﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using ConexionBaseDeDatos;

namespace Negocios
{
    public class CoordinadorDAO
    {
        public Coordinador GetByIDCoordiandor(string idCoordinador)
        {
            Coordinador coordinador = new Coordinador();
            GestionBaseDeDatos dbManager = new GestionBaseDeDatos();
            using (SqlConnection conexion = dbManager.GetConnection())
            {
                conexion.Open();
                using (SqlCommand command = new SqlCommand("Select * from Alumno where userid=@IDCoordinador", conexion))
                {
                    command.Parameters.Add(new SqlParameter("IDCoordinador", idCoordinador));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        coordinador.Nombre = reader["Nombre"].ToString();
                        coordinador.ApellidoPaterno = reader["ApellidoPaterno"].ToString();
                        coordinador.ApellidoMaterno = reader["ApellidoMaterno"].ToString();
                        coordinador.NumeroPersonal = (int)reader["NumeroPersonal"];
                    }
                }
                dbManager.CloseConnection();
            }
            return coordinador;
        }
    }
}
