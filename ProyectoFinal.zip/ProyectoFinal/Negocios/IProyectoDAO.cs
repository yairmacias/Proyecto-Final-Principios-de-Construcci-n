﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios
{
   public  interface IProyectoDAO
    {

        Proyecto GetByIDProyecto(String idProyecto);
        Proyecto GetByNombre(String nombre);
        Proyecto GetByActividad(String actividad);
        Proyecto GetByCalendarizacion(String calendarizacion);
        Proyecto GetByDescripcionGeneral(String descripcionGeneral);
        Proyecto GetByDias(String dias);
        Proyecto GetByDuracion(String duracion);
        Proyecto GetByFuncion(String funcion);
        Proyecto GetByHora(String hora);
        Proyecto GetByMetodologia(String metodologia);
        Proyecto GetByObjetivoGeneral(String objetivoGeneral);
        Proyecto GetByObjetivoInmediato(String objetivoInmediato);
        Proyecto GetByObjetivoMediato(String objetivoMediato);
        Proyecto GetByRecursoEconomico(String rescursoEconomico);
        Proyecto GetByRecursoHumano(String recursoHumano);
        Proyecto GetByRecursoMaterial(String recursoMaterial);
        Proyecto GetByResponsabilidad(String responsabilidad);
        List<Proyecto> GetProyecto(String criteria);
    }
}
