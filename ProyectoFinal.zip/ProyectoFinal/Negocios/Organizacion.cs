﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios
{
    public class Organizacion
    {
        public String IDOrganizacion { get; set; }
        public String Nombre { get; set; }
        public String Calle { get; set; }
        public String Ciudad { get; set; }
        public String CodigoPostal { get; set; }
        public String Colonia { get; set; }
        public String CorreoElectronico { get; set; }
        public String Estado { get; set; }
        public String NumeroInterno { get; set; }
        public String Sector { get; set; }
        public String Telefono { get; set; }

    }
}
