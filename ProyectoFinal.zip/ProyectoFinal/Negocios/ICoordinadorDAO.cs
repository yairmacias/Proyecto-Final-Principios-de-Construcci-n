﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios
{
   public interface ICoordinadorDAO
    {
        Coordinador GetByIDCoordinador(String coordinador);
        Coordinador GetByNombre(String nombre);
        Coordinador GetByApellidoPaterno(String apellidoPaterno);
        Coordinador GetByApellidoMaterno(String apellidoMaterno);
        Coordinador GetByNumeroPersonal(String numeroPersonal);
        List<Coordinador> GetCoordinador(String criteria);

    }
}
