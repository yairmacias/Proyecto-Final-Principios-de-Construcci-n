﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace ProyectoFinal
{
    public class Negocio
    {

        public Boolean validarText(Window form)
        {
            object a = form.Content;
            
            foreach (Control o in form.)
            {


            }
        }
    }
}
