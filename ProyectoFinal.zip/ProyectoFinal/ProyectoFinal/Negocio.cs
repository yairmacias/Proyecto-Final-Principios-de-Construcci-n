﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ProyectoFinal
{
    public class Negocio
    {

       public static Boolean validarTextbox(UIElementCollection n)
        {
            Boolean bandera = false;

            foreach (UIElement e in n)
            {
                if (e is TextBox)
                {
                    TextBox tb = (TextBox)e;
                    if (tb.Text == "")
                    {
                        bandera = false;
                        break;
                    }
                    else
                    { bandera = true; }
                }
            }

            return bandera;
        }

        public static Boolean guardarRegistroAlumno(Alumno alum)
        {
            return ConexionBaseDeDatos.guardarRegistro(alum);
        }

    }
}
