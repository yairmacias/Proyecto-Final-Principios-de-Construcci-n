﻿using LogicaDeNegocios;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
namespace ProyectoFinalConstruccion
{
    /// <summary>
    /// Lógica de interacción para IUVisualizarProyecto.xaml
    /// </summary>
    public partial class IUVisualizarProyecto : Window
    {
        public IUVisualizarProyecto()
        {
            InitializeComponent();
            DataTable TablaMostrar = ProyectoDAO.ConsultarProyecto();
            DataGridMostrarProyecto.ItemsSource = TablaMostrar.DefaultView;
        }
    }
}
