﻿using LogicaDeNegocios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProyectoFinalConstruccion
{
    /// <summary>
    /// Lógica de interacción para IURegistrarAlumno.xaml
    /// </summary>
    public partial class IURegistrarAlumno : Window
    {
        public IURegistrarAlumno()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Boolean bandera = ValidacionDeInterfaz.ValidarTextbox(GridContenedor.Children);

            if (bandera)
            {
                Alumno alumno = new Alumno(TextBoxNombre.Text, TextBoxApellidoPaterno.Text, TextBoxApellidoMaterno.Text, TextBoxCorreoElectronico.Text, TextBoxMatricula.Text, TextBoxSeccion.Text, TextBoxBloque.Text);
                int ValorRecibidoDelDAO = GuardarRegistros.GuardarRegistroAlumno(alumno);

                if (ValorRecibidoDelDAO < 0)
                {
                    MessageBox.Show("Los datos ingresados son erroneos");
                }
                if (ValorRecibidoDelDAO == 0)
                {
                    MessageBox.Show("No se ingreso ningun dato dentro del sistema");
                }
                if (ValorRecibidoDelDAO >= 1)
                {
                    MessageBox.Show("Datos ingresado correctamente al sistema");
                }

            }
            else
                MessageBox.Show("Error, faltan campos por llenar");
        }

        private void ButtonRegresar_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            IUMenuPrincipal  MenuPrincipal = new IUMenuPrincipal();
            MenuPrincipal.Show();
        }

        private void ButtonRegresar_Click_1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            IUTipoDeCuenta TiposDeCuentas = new IUTipoDeCuenta();
            TiposDeCuentas.Show();
        }
        private void TextBoxNombre_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (ValidacionDeInterfaz.ValidarCamposCaracter(sender, e))
            {
                MessageBox.Show("Solo se aceptan caracter A-Z");
            }
        }

        private void TextBoxApellidoPaterno_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (ValidacionDeInterfaz.ValidarCamposCaracter(sender, e))
            {
                MessageBox.Show("Solo se aceptan caracter A-Z");
            }
        }

        private void TextBoxApellidoMaterno_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (ValidacionDeInterfaz.ValidarCamposCaracter(sender, e))
            {
                MessageBox.Show("Solo se aceptan caracter A-Z");
            }
        }

        private void TextBoxSeccion_KeyUp(object sender, KeyEventArgs e)
        {
            if (ValidacionDeInterfaz.ValidarCamposNumericos(sender, e))
            {
                MessageBox.Show("Solo se aceptan valores numericos");
            }
        }

        private void TextBoxBloque_KeyUp(object sender, KeyEventArgs e)
        {
            if (ValidacionDeInterfaz.ValidarCamposNumericos(sender, e))
            {
                MessageBox.Show("Solo se aceptan valores numericos");
            }
        }
    }
}
