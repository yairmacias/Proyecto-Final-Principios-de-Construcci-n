﻿using LogicaDeNegocios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProyectoFinalConstruccion
{

    public partial class IUInicioSesionCoordinador : Window
    {
        public IUInicioSesionCoordinador()
        {
            InitializeComponent();
        }

        private void ButtonInicioSesion_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int NumeroPersonal = Convert.ToInt32(TextBoxNumeroPersonal.Text);
                String IdentificadorPersonal = TextBoxID.Text;

                if (TextBoxNumeroPersonal.Text == "" || TextBoxID.Text == "")
                {
                    MessageBox.Show("Error, faltan campos por llenar");
                }
                else
                {
                    Boolean bandera = ValidacionDeInterfaz.ValidarCuentaCoordinador(NumeroPersonal, IdentificadorPersonal);

                    if (bandera)
                    {
                        this.Hide();
                        IUValidacionesCoordianador ValidacionesCoordinador = new IUValidacionesCoordianador();
                        ValidacionesCoordinador.Show();
                    }
                    else
                    {
                        MessageBox.Show("Coordinador no validado dentro del sistema");
                    }

                }
            }
            catch(System.FormatException ExcepcionFormato)
            {
                MessageBox.Show("Campo sin argumentos" + ExcepcionFormato);
            }
           
        }

        private void ButtonRegresarMenu_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            IUMenuPrincipal MenuPrincipal = new IUMenuPrincipal();
            MenuPrincipal.Show();
        }

        private void TextBoxNumeroPersonal_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (ValidacionDeInterfaz.ValidarCamposNumericos(sender, e))
            {
                MessageBox.Show("No se acepta caracteres, solo numeros");
            }
        }
    }
}
