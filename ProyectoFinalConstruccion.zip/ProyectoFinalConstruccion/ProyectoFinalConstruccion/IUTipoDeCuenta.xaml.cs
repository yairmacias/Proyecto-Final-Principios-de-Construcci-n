﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProyectoFinalConstruccion
{
    /// <summary>
    /// Lógica de interacción para IUTipoDeCuenta.xaml
    /// </summary>
    public partial class IUTipoDeCuenta : Window
    {
        public IUTipoDeCuenta()
        {
            InitializeComponent();
            ComboBoxCuentas.Items.Add("Registarse como Alumno");
            ComboBoxCuentas.Items.Add("Registrarse como Encargado");
        }

        private void ButtonAceptar_Click(object sender, RoutedEventArgs e)
        {
            switch (ComboBoxCuentas.SelectedIndex)
            {
                case 0:
                    this.Hide();
                    IURegistrarAlumno RegistroAlumno = new IURegistrarAlumno();
                    RegistroAlumno.Show();
                    break;
                case 1:
                    this.Hide();
                    IURegistrarEncargado RegistroEncargado = new IURegistrarEncargado();
                    RegistroEncargado.Show();
                    break;
            }

        }

        private void ButtonRegresar_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            IUMenuPrincipal MenuPrincipal = new IUMenuPrincipal();
            MenuPrincipal.Show();

        }
    
    }
}
