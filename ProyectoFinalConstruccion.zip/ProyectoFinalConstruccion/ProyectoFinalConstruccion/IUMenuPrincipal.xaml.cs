﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProyectoFinalConstruccion
{

    public partial class IUMenuPrincipal : Window
    {
        public IUMenuPrincipal()
        {
            InitializeComponent();
        }
        private void ButtonInicioCoordinador_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            IUInicioSesionCoordinador InicioCoordinador = new IUInicioSesionCoordinador();
            InicioCoordinador.Show();
        }

        private void ButtonInicioAlumno_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            IUInicioSesionAlumno InicioAlumno = new IUInicioSesionAlumno();
            InicioAlumno.Show();
        }

        private void ButtonInicioEncargado_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            IUInicioSesionEncargado InicioEncargado = new IUInicioSesionEncargado();
            InicioEncargado.Show();
        }

        private void ButtonNuevaCuenta_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            IUTipoDeCuenta TipoCuenta = new IUTipoDeCuenta();
            TipoCuenta.Show();
        }

    }
}
