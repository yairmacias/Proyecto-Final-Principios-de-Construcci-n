﻿using LogicaDeNegocios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProyectoFinalConstruccion
{
 
    public partial class IUInicioSesionEncargado : Window
    {
        public IUInicioSesionEncargado()
        {
            InitializeComponent();
        }

        private void ButtonRegresarMenu_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            IUMenuPrincipal MenuPrincipal = new IUMenuPrincipal();
            MenuPrincipal.Show();
        }

        private void ButtonIniciarSesion_Click(object sender, RoutedEventArgs e)
        {
            String CorreoElectronico = TextBoxCorreoElectronico.Text;
            String IdentificadorPersonal = TextBoxID.Text;

            if (TextBoxCorreoElectronico.Text == "" || TextBoxID.Text == "")
            {
                MessageBox.Show("Error, faltan campos por llenar");
            }
            else
            {
                Boolean bandera = ValidacionDeInterfaz.ValidarCuentaEncargado(CorreoElectronico, IdentificadorPersonal);

                if (bandera)
                {
                    this.Hide();
                    IURegistrosDeEncargado RegistrosDeEncargado = new IURegistrosDeEncargado();
                    RegistrosDeEncargado.Show();
                }
                else
                {
                    MessageBox.Show("Encargado no validado dentro del sistema");
                }
            }
        }

    }
}
