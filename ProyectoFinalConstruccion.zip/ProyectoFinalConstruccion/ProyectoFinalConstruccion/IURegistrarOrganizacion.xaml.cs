﻿using LogicaDeNegocios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProyectoFinalConstruccion
{
    /// <summary>
    /// Lógica de interacción para IURegistrarOrganizacion.xaml
    /// </summary>
    public partial class IURegistrarOrganizacion : Window
    {
        public IURegistrarOrganizacion()
        {
            InitializeComponent();
        }

        private void ButtonAgregar_Click(object sender, RoutedEventArgs e)
        {
            Boolean bandera = ValidacionDeInterfaz.ValidarTextbox(GridContenedorOrganizacion.Children);

            if (bandera)
            {
                Organizacion organizacion = new Organizacion(TextBoxID.Text, TextBoxNombre.Text, Convert.ToInt32 (TextBoxNumeroInterno.Text),TextBoxCalle.Text, Convert.ToInt32 (TextBoxNumeroExterior.Text), Convert.ToInt32(TextBoxPoblacionAtendida.Text), TextBoxUsuarioDirecto.Text, TextBoxUsuarioIndirecto.Text, TextBoxColonia.Text, TextBoxCodigoPostal.Text
                                                            , TextBoxCiudad.Text, TextBoxEstado.Text, Convert.ToInt32(TextBoxTelefono.Text), TextBoxCorreoElectronico.Text);
                int ValorRecibidoDelDAO = ValidacionDeInterfaz.GuardarRegistroOrganizacion(organizacion);

                if (ValorRecibidoDelDAO < 0)
                {
                    MessageBox.Show("Los datos ingresados son erroneos");
                }
                if (ValorRecibidoDelDAO == 0)
                {
                    MessageBox.Show("No se ingreso ningun dato dentro del sistema");
                }
                if (ValorRecibidoDelDAO >= 1)
                {
                    MessageBox.Show("Datos ingresado correctamente al sistema");
                }

            }
            else
                MessageBox.Show("Error, faltan campos por llenar");
        }

        private void TextBoxID_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
