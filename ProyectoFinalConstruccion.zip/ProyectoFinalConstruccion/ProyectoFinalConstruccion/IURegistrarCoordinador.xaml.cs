﻿using LogicaDeNegocios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProyectoFinalConstruccion
{

    public partial class IURegistrarCoordinador : Window
    {
        public IURegistrarCoordinador()
        {
            InitializeComponent();
        }

        private void ButtonAgregar_Click(object sender, RoutedEventArgs e)
        {
            Boolean bandera = ValidacionDeInterfaz.ValidarTextbox(GridContenedorCoordinador.Children);

            if (bandera)
            {
                Coordinador coordinador = new Coordinador(TextBoxIDE.Text, TextBoxNombre.Text, TextBoxApellidoPaterno.Text, TextBoxApellidoMaterno.Text, Convert.ToInt32 (TextBoxNumeroPersonal.Text));
                int ValorRecibidoDelDAO = GuardarRegistros.GuardarRegistroCoordinador(coordinador);

                if (ValorRecibidoDelDAO < 0)
                {
                    MessageBox.Show("Los datos ingresados son erroneos");
                }
                if (ValorRecibidoDelDAO == 0)
                {
                    MessageBox.Show("No se ingreso ningun dato dentro del sistema");
                }
                if (ValorRecibidoDelDAO >= 1)
                {
                    MessageBox.Show("Datos ingresado correctamente al sistema");
                }

            }
            else
                MessageBox.Show("Error, faltan campos por llenar");
        }

        private void ButtonRegresar_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            IUMenuPrincipal Menu = new IUMenuPrincipal();
            Menu.Show();
        }

        private void TextBoxNombre_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (ValidacionDeInterfaz.ValidarCamposCaracter(sender, e))
            {
                MessageBox.Show("Solo se aceptan caracter A-Z");
            }
        }

        private void TextBoxApellidoPaterno_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (ValidacionDeInterfaz.ValidarCamposCaracter(sender, e))
            {
                MessageBox.Show("Solo se aceptan caracter A-Z");
            }
        }

        private void TextBoxApellidoMaterno_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (ValidacionDeInterfaz.ValidarCamposCaracter(sender, e))
            {
                MessageBox.Show("Solo se aceptan caracter A-Z");
            }
        }

        private void TextBoxNumeroPersonal_KeyDown(object sender, KeyEventArgs e)
        {
            if (ValidacionDeInterfaz.ValidarCamposNumericos(sender, e))
            {
                MessageBox.Show("Solo se aceptan valores numericos");
            }
        }
    }
}
