﻿using LogicaDeNegocios;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProyectoFinalConstruccion
{
    /// <summary>
    /// Lógica de interacción para IUValidarReporteOrganizacion.xaml
    /// </summary>
    public partial class IUValidarReporteOrganizacion : Window
    {
        public IUValidarReporteOrganizacion()
        {
            InitializeComponent();
            DataTable TablaMostrar = OrganizacionDAO.ConsultarOrganizacion();
            DataGridOrganizacion.ItemsSource = TablaMostrar.DefaultView;
        }

        private void ButtonActualizar_Click(object sender, RoutedEventArgs e)
        {
            List<String> IDOrganizacion = new List<String>();

            foreach (DataRowView a in DataGridOrganizacion.ItemsSource)
            {
                if (Convert.ToInt32(a.Row[14]) == 1)
                {
                    IDOrganizacion.Add(Convert.ToString(a[0]));
                }
            }

            OrganizacionDAO.ActualizarReporte(IDOrganizacion);
            DataTable TablaMostrar = OrganizacionDAO.ConsultarOrganizacion();
            DataGridOrganizacion.ItemsSource = TablaMostrar.DefaultView;
        }
    }
}
