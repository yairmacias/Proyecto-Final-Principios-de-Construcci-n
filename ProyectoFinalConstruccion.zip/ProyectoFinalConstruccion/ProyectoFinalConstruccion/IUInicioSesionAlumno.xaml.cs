﻿using LogicaDeNegocios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProyectoFinalConstruccion
{

    public partial class IUInicioSesionAlumno : Window
    {
        public IUInicioSesionAlumno()
        {
            InitializeComponent();
        }

        private void ButtonRegresarMenu_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            IUMenuPrincipal MenuPrincipal = new IUMenuPrincipal();
            MenuPrincipal.Show();
        }

        private void ButtonInicarSesion_Click(object sender, RoutedEventArgs e)
        {
            String CorreoElectronico = TextBoxCorreoElectronico.Text;
            String Matricula = TextBoxMatricula.Text;

            if (TextBoxCorreoElectronico.Text == "" || TextBoxMatricula.Text == "")
            {
                MessageBox.Show("Error, faltan campos por llenar");
            }
            else
            {
                Boolean bandera = ValidacionDeInterfaz.ValidarCuentaAlumno(CorreoElectronico, Matricula);

                if (bandera)
                {
                    IUVisualizarProyecto VisualizarProyecto = new IUVisualizarProyecto();
                    VisualizarProyecto.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Alumno no validado dentro del sistema");
                }
            }
        }
    }
}
