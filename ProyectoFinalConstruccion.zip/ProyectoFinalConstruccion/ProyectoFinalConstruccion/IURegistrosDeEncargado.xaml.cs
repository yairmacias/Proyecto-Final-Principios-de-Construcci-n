﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProyectoFinalConstruccion
{
    /// <summary>
    /// Lógica de interacción para IURegistrosDeEncargado.xaml
    /// </summary>
    public partial class IURegistrosDeEncargado : Window
    {
        public IURegistrosDeEncargado()
        {
            InitializeComponent();
            ComboBoxRegistros.Items.Add("Registro organización");
            ComboBoxRegistros.Items.Add("Registro Proyecto");
        }

        private void ButtonAceptar_Click(object sender, RoutedEventArgs e)
        {
            switch (ComboBoxRegistros.SelectedIndex)
            {
                case 0:

                    this.Hide();
                    IURegistrarOrganizacion RegistroOrganizacion = new IURegistrarOrganizacion();
                    RegistroOrganizacion.Show();
                    break;
                case 1:

                    this.Hide();
                    IURegistrarProyecto RegistroProyecto = new IURegistrarProyecto();
                    RegistroProyecto.Show();
                    break;

            }
        }

        private void ButtonRegresarMenu_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            IUMenuPrincipal MenuPrincipal = new IUMenuPrincipal();
            MenuPrincipal.Show();
        }
    }
}
