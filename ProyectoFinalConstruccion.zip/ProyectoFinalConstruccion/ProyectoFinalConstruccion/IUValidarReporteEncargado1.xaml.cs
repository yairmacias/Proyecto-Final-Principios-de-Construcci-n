﻿using LogicaDeNegocios;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProyectoFinalConstruccion
{
    /// <summary>
    /// Lógica de interacción para IUValidarReporteEncargado1.xaml
    /// </summary>
    public partial class IUValidarReporteEncargado1 : Window
    {
        public IUValidarReporteEncargado1()
        {
            InitializeComponent();
            DataTable TablaMostrar = EncargadoDAO.ConsultarEncargado();
            DataGridEncargado.ItemsSource = TablaMostrar.DefaultView;
        }

        private void ButtonActualizar_Click(object sender, RoutedEventArgs e)
        {
            List<String> idEncargado = new List<String>();

            foreach (DataRowView a in DataGridEncargado.ItemsSource)
            {
                if (Convert.ToInt32(a.Row[7]) == 1)
                {
                    idEncargado.Add(Convert.ToString(a[0]));
                }
            }
            EncargadoDAO.ActualizarReporte(idEncargado);
            DataTable TablaMostrar = EncargadoDAO.ConsultarEncargado();
            DataGridEncargado.ItemsSource = TablaMostrar.DefaultView;
        }


    }
}
