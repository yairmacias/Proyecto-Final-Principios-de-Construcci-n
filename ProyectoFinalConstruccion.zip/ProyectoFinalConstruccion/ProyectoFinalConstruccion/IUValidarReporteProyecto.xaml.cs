﻿using LogicaDeNegocios;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProyectoFinalConstruccion
{
    /// <summary>
    /// Lógica de interacción para IUValidarReporteProyecto.xaml
    /// </summary>
    public partial class IUValidarReporteProyecto : Window
    {
        public IUValidarReporteProyecto()
        {
            InitializeComponent();
            DataTable TablaMostrar = ProyectoDAO.ConsultarProyecto();
            DataGridProyecto.ItemsSource = TablaMostrar.DefaultView;
        }

        private void ButtonActualizar_Click(object sender, RoutedEventArgs e)
        {
            List<String> IDProyecto = new List<String>();

            foreach (DataRowView a in DataGridProyecto.ItemsSource)
            {
                if (Convert.ToInt32(a.Row[15]) == 1)
                {
                    IDProyecto.Add(Convert.ToString(a[0]));
                }
            }

            ProyectoDAO.ActualizarReporte(IDProyecto);
            DataTable TablaMostrar = ProyectoDAO.ConsultarProyecto();
            DataGridProyecto.ItemsSource = TablaMostrar.DefaultView;

        }
    }
}
