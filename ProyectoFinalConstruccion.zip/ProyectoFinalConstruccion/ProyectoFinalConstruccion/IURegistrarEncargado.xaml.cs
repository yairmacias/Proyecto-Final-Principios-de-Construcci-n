﻿using LogicaDeNegocios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProyectoFinalConstruccion
{
    public partial class IURegistrarEncargado : Window
    {
        public IURegistrarEncargado()
        {
            InitializeComponent();
        }

        private void ButtonAgregar_Click(object sender, RoutedEventArgs e)
        {
            Boolean bandera = ValidacionDeInterfaz.ValidarTextbox(GridContenedorEncargado.Children);

            if (bandera)
            {
                Encargado encargado = new Encargado(TextBoxIDE.Text, TextBoxNombre.Text, TextBoxApellidoPaterno.Text, TextBoxApellidoMaterno.Text, TextBoxCargo.Text, TextBoxCorreoElectronico.Text);
                int ValorRecibidoDelDAO = GuardarRegistros.GuardarRegistroEncargado(encargado);

                if (ValorRecibidoDelDAO < 0)
                {
                    MessageBox.Show("Los datos ingresados son erroneos");
                }
                if (ValorRecibidoDelDAO == 0)
                {
                    MessageBox.Show("No se ingreso ningun dato dentro del sistema");
                }
                if (ValorRecibidoDelDAO >= 1)
                {
                    MessageBox.Show("Datos ingresado correctamente al sistema");
                }

            }
            else
                MessageBox.Show("Error, faltan campos por llenar");
        }

        private void ButtonRegresar_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            IUTipoDeCuenta TiposCuentas = new IUTipoDeCuenta();
            TiposCuentas.Show();
        }

        private void TextBoxNombre_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (ValidacionDeInterfaz.ValidarCamposCaracter(sender, e))
            {
                MessageBox.Show("Solo se aceptan caracter A-Z");
            }
        }

        private void TextBoxApellidoPaterno_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (ValidacionDeInterfaz.ValidarCamposCaracter(sender, e))
            {
                MessageBox.Show("Solo se aceptan caracter A-Z");
            }
        }

        private void TextBoxApellidoMaterno_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (ValidacionDeInterfaz.ValidarCamposCaracter(sender, e))
            {
                MessageBox.Show("Solo se aceptan caracter A-Z");
            }
        }

        private void TextBoxCargo_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (ValidacionDeInterfaz.ValidarCamposCaracter(sender, e))
            {
                MessageBox.Show("Solo se aceptan caracter A-Z");
            }
        }
    }
}
