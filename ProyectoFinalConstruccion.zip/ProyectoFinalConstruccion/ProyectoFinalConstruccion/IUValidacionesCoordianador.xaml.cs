﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProyectoFinalConstruccion
{
    /// <summary>
    /// Lógica de interacción para IUValidacionesCoordianador.xaml
    /// </summary>
    public partial class IUValidacionesCoordianador : Window
    {
        public IUValidacionesCoordianador()
        {
            InitializeComponent();

            ComboBoxValidaciones.Items.Add("Organización");
            ComboBoxValidaciones.Items.Add("Proyecto");
            ComboBoxValidaciones.Items.Add("Alumno");
            ComboBoxValidaciones.Items.Add("Encargado");

        }

        private void ButtonAceptar_Click(object sender, RoutedEventArgs e)
        {

            switch(ComboBoxValidaciones.SelectedIndex)
            {
                case 0:
                    
                    IUValidarReporteOrganizacion ValidacionOrganizacion = new IUValidarReporteOrganizacion();
                    ValidacionOrganizacion.ShowDialog();
                    break;
                case 1:
                    
                    IUValidarReporteProyecto ValidacionProyecto = new IUValidarReporteProyecto();
                    ValidacionProyecto.ShowDialog();
                    break;

                case 2:
                    
                    IUValidarReporteAlumno ValidacionAlumno = new IUValidarReporteAlumno();
                    ValidacionAlumno.ShowDialog();
                    break;

                case 3:

                    IUValidarReporteEncargado1 ValidacionEncargado = new IUValidarReporteEncargado1();
                    ValidacionEncargado.ShowDialog();
                    break;
                    
            }

        }

        private void ButtonRegesarMenu_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            IUMenuPrincipal MenuPrincipal = new IUMenuPrincipal();
            MenuPrincipal.Show();
        }
    }
}
