﻿using LogicaDeNegocios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProyectoFinalConstruccion
{
    /// <summary>
    /// Lógica de interacción para IURegistrarProyecto.xaml
    /// </summary>
    public partial class IURegistrarProyecto : Window
    {
        public IURegistrarProyecto()
        {
            InitializeComponent();
        }

        private void ButtonAgregar_Click(object sender, RoutedEventArgs e)
        {
            Boolean bandera = ValidacionDeInterfaz.ValidarTextbox(GridContendorProyecto.Children);

            if (bandera)
            {
                Proyecto proyecto = new Proyecto(TextBoxID.Text, TextBoxActividades.Text, TextBoxCalendarizacion.Text, TextBoxDescripcionGeneral.Text, Convert.ToInt32(TextBoxDuracion.Text), TextBoxFunciones.Text, TextBoxMetodologia.Text, TextBoxNombre.Text, TextBoxObjetivoGeneral.Text, TextBoxObjetivoInmediato.Text, TextBoxRecursosHumanos.Text, TextBoxResponsabilidades.Text,TextBoxMateriales.Text);
                int ValorRecibidoDelDAO = GuardarRegistros.GuardarRegistroProyecto(proyecto);

                if (ValorRecibidoDelDAO < 0)
                {
                    MessageBox.Show("Los datos ingresados son erroneos");
                }
                if (ValorRecibidoDelDAO == 0)
                {
                    MessageBox.Show("No se ingreso ningun dato dentro del sistema");
                }
                if (ValorRecibidoDelDAO >= 1)
                {
                    MessageBox.Show("Datos ingresado correctamente al sistema");
                }

            }
            else
                MessageBox.Show("Error, faltan campos por llenar");
        }

        private void TextBoxDuracion_KeyUp(object sender, KeyEventArgs e)
        {
            if (ValidacionDeInterfaz.ValidarCamposNumericos(sender, e))
            {
                MessageBox.Show("Solo se aceptan valores numericos");
            }
        }

        private void ButtonRegresar_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            IURegistrosDeEncargado RegistrosEncargado = new IURegistrosDeEncargado();
            RegistrosEncargado.Show();
        }
    }
}
