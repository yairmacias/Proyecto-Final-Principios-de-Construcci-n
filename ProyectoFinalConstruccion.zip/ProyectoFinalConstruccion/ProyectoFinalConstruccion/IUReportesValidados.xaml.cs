﻿using LogicaDeNegocios;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProyectoFinalConstruccion
{
    /// <summary>
    /// Lógica de interacción para IUReportesValidados.xaml
    /// </summary>
    public partial class IUReportesValidados : Window
    {
        public IUReportesValidados()
        {
            InitializeComponent();
            List<DataTable> lista = AlumnoDAO.ConsultarAlumnoEncargado();
            DataGridEncargado.ItemsSource = lista[0].DefaultView;
            DataGridAlumno.ItemsSource = lista[1].DefaultView;

        }

        private void ButtonActualizar_Click(object sender, RoutedEventArgs e)
        {
            List<String> matriculas = new List<String>();

            foreach (DataRowView a in DataGridAlumno.ItemsSource)
            {
                if (Convert.ToInt32(a.Row[8]) == 1)
                {
                    matriculas.Add(Convert.ToString(a[0]));
                }
            }

            AlumnoDAO.ActualizarReporte(matriculas);
            List<DataTable> lista = AlumnoDAO.ConsultarAlumnoEncargado();
            DataGridAlumno.ItemsSource = lista[1].DefaultView;

        }
    }
}
