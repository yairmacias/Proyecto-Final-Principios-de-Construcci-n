﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BaseDeDatos;


namespace PruebasUnitarias
{
    [TestClass]
    public class PruebaConexion
    {
        [TestMethod]
        public void AbrirConexion()
        {
           

        }

        [TestMethod]
        public void TestMethod2()
        {


        }
    }
}
