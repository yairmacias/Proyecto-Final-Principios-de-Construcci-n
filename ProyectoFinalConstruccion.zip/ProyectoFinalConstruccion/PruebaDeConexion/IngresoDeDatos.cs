﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BaseDeDatos;
using LogicaDeNegocios;
using System.Data.SqlClient;
using System.Configuration;


namespace PruebaConexion
{
    [TestClass]
    public class IngresoDeDatos
    {

        [TestMethod]
        public void RegistrarEncargado()
        {
            Encargado NuevoEncargado = new Encargado();

            NuevoEncargado.Nombre = "Marco";
            NuevoEncargado.ApellidoPaterno = "Hernandez";
            NuevoEncargado.ApellidoMaterno = "Luna";
            NuevoEncargado.CorreoElectronico = "marco@lania.mx";
            NuevoEncargado.IDEncargado = "S90038993";
            NuevoEncargado.Cargo = "Administrador del control escolar";

            int resultado = EncargadoDAO.ResgistrarDatosEncargado(NuevoEncargado);
            Assert.AreEqual(resultado, 1);
        }

        [TestMethod]
        public void RegistrarAlumno()
        {
            Alumno NuevoAlumno = new Alumno();

            NuevoAlumno.Nombre = "Marcela";
            NuevoAlumno.ApellidoPaterno = "Días";
            NuevoAlumno.ApellidoMaterno = "Gonzales";
            NuevoAlumno.CorreoElectronico = "Marcela_Gonzales@gmail.com";
            NuevoAlumno.Matricula = "S16011731";
            NuevoAlumno.Seccion = "2";
            NuevoAlumno.Bloque = "5";

            int resultado = AlumnoDAO.ResgistrarDatosAlumno(NuevoAlumno);
            Assert.AreEqual(resultado, 1);

        }

        [TestMethod]
        public void RegistrarCoordinador()
        {
            Coordinador NuevoCoordinador = new Coordinador();

            NuevoCoordinador.Nombre = "Juan Carlos";
            NuevoCoordinador.ApellidoPaterno = "Perez";
            NuevoCoordinador.ApellidoMaterno = "Arriaga";
            NuevoCoordinador.IDCoordinador = "S90050281";
            NuevoCoordinador.NumeroPersonal = 90050281;
        }

        [TestMethod]
        public void RegitsrarOrganizacion()
        {
            Organizacion NuevaOrganizacion = new Organizacion();

            NuevaOrganizacion.Nombre = "LANIA";
            NuevaOrganizacion.IDOrganizacion = "400178349";
            NuevaOrganizacion.NumeroExterno = 20;
            NuevaOrganizacion.NumeroInterno = 0;
            NuevaOrganizacion.PoblacionAtendida = 100;
            NuevaOrganizacion.Telefono = 8416100;
            NuevaOrganizacion.UsuarioDirecto = "Cora";
            NuevaOrganizacion.UsuarioIndirecto = "Cristina";
            NuevaOrganizacion.Calle = "Rebsamen";
            NuevaOrganizacion.Estado = "Veracruz";
            NuevaOrganizacion.Ciudad = "Xalapa";
            NuevaOrganizacion.CodigoPostal = "91190";
            NuevaOrganizacion.CorreoElectronico = "Lania_Dudas@lania.mx";
            NuevaOrganizacion.IDOrganizacion = "10035501";
            NuevaOrganizacion.Colonia = "Centro";

            int resultado = OrganizacionDAO.ResgistrarDatosOrganizacion(NuevaOrganizacion);
            Assert.AreEqual(resultado, 1);
        }

        [TestMethod]
        public void RegistrarProyecto()
        {
            Proyecto NuevoProyecto = new Proyecto();

            NuevoProyecto.Nombre = "Sistema De Vialidad Publica";
            NuevoProyecto.IDProyecto = "100904523";
            NuevoProyecto.ObjetivoGeneral = "Crear un sistema que ayude a los estudiantes a escoger un transporte publico que los lleve a su destino";
            NuevoProyecto.ObjetivoInmediato = "Realizacion de la parte de diseño con respecto al sistema";
            NuevoProyecto.RecursoHumano = "Estudiantes de la licenciatura en ingenieria de software";
            NuevoProyecto.RecursoMaterial = "Equipo de computo de la factultad";
            NuevoProyecto.Responsabilidad = "Realizacion de los modulos indicados por el encargado de la organizacion";
            NuevoProyecto.Metodologia = "Metodologia de prototipo";
            NuevoProyecto.Duracion = 8;
            NuevoProyecto.Calendarizacion = "2019-06-20";
            NuevoProyecto.DescripcionGeneral = "Sistema que ayude al desplazamiento de los alumnos de la Universidad Veracruzana";
            NuevoProyecto.Actividad = "Las propocionadas por el Coordinador";
            NuevoProyecto.Funcion = "Diseño e implementacion";

            int resultado = ProyectoDAO.ResgistrarDatosProyecto(NuevoProyecto);
            Assert.AreEqual(resultado, 1);
        }

        [TestMethod]
        public void ResgistrarEncargadoMinimosParametros()
        {
            Encargado NuevoEncargado = new Encargado();

            NuevoEncargado.Nombre = "M";
            NuevoEncargado.ApellidoPaterno = "H";
            NuevoEncargado.ApellidoMaterno = "L";
            NuevoEncargado.CorreoElectronico = "m";
            NuevoEncargado.IDEncargado = "S";
            NuevoEncargado.Cargo = "A";

            int resultado = EncargadoDAO.ResgistrarDatosEncargado(NuevoEncargado);
            Assert.AreEqual(resultado, 1);
        }

        [TestMethod]
        public void RegistrarAlumnoMinimosParametros()
        {
            Alumno NuevoAlumno = new Alumno();

            NuevoAlumno.Nombre = "M";
            NuevoAlumno.ApellidoPaterno = "D";
            NuevoAlumno.ApellidoMaterno = "G";
            NuevoAlumno.CorreoElectronico = "b";
            NuevoAlumno.Matricula = "S";
            NuevoAlumno.Seccion = "2";
            NuevoAlumno.Bloque = "5";

            int resultado = AlumnoDAO.ResgistrarDatosAlumno(NuevoAlumno);
            Assert.AreEqual(resultado, 1);
        }

        [TestMethod]
            public void RegistrarCoordinadorMinimosParametros()
        {
            Coordinador NuevoCoordinador = new Coordinador();

            NuevoCoordinador.Nombre = "A";
            NuevoCoordinador.ApellidoPaterno = "P";
            NuevoCoordinador.ApellidoMaterno = "A";
            NuevoCoordinador.IDCoordinador = "S9";
            NuevoCoordinador.NumeroPersonal = 9;

            int resultado = CoordinadorDAO.RegistraDatosCoordinador(NuevoCoordinador);
            Assert.AreEqual(resultado, 1);
        }

        [TestMethod]
        public void RegistrarCoordinadorMinimosOrganizacion()
        {
            Organizacion NuevaOrganizacion = new Organizacion();

            NuevaOrganizacion.Nombre = "L";
            NuevaOrganizacion.IDOrganizacion = "1";
            NuevaOrganizacion.NumeroExterno = 1;
            NuevaOrganizacion.NumeroInterno = 0;
            NuevaOrganizacion.PoblacionAtendida = 1;
            NuevaOrganizacion.Telefono = 1;
            NuevaOrganizacion.UsuarioDirecto = "C";
            NuevaOrganizacion.UsuarioIndirecto = "C";
            NuevaOrganizacion.Calle = "R";
            NuevaOrganizacion.Estado = "V";
            NuevaOrganizacion.Ciudad = "X";
            NuevaOrganizacion.CodigoPostal = "9";
            NuevaOrganizacion.CorreoElectronico = "L";
            NuevaOrganizacion.IDOrganizacion = "1";
            NuevaOrganizacion.Colonia = "C";

            int resultado = OrganizacionDAO.ResgistrarDatosOrganizacion(NuevaOrganizacion);
            Assert.AreEqual(resultado, 1);
        }

        [TestMethod]
        public void RegistrarProyectoMinimoParametros()
        {
            Proyecto NuevoProyecto = new Proyecto();

            NuevoProyecto.Nombre = "S";
            NuevoProyecto.IDProyecto = "1";
            NuevoProyecto.ObjetivoGeneral = "C";
            NuevoProyecto.ObjetivoInmediato = "R";
            NuevoProyecto.RecursoHumano = "E";
            NuevoProyecto.RecursoMaterial = "E";
            NuevoProyecto.Responsabilidad = "R";
            NuevoProyecto.Metodologia = "M";
            NuevoProyecto.Duracion = 8;
            NuevoProyecto.Calendarizacion = "2019-06-20";
            NuevoProyecto.DescripcionGeneral = "S";
            NuevoProyecto.Actividad = "L";
            NuevoProyecto.Funcion = "D";

            int resultado = ProyectoDAO.ResgistrarDatosProyecto(NuevoProyecto);
            Assert.AreEqual(resultado, 1);
        }

        [TestMethod]
        public void RegistrarEncargadoFueraParametros()
        {
            Encargado NuevoEncargado = new Encargado();
            
                NuevoEncargado.Nombre = "Eduardo";
                NuevoEncargado.ApellidoPaterno = "Lopez";
                NuevoEncargado.ApellidoMaterno = "Sanchez";
                NuevoEncargado.CorreoElectronico = "eduardo_administrador@hotmail.com";
                NuevoEncargado.IDEncargado = "S900389934";
                NuevoEncargado.Cargo = "Administrador de contaduria";

                int resultado = EncargadoDAO.ResgistrarDatosEncargado(NuevoEncargado);
                Assert.AreEqual(resultado, 1);
 
        }

        [TestMethod]
        public void RegistrarAlumnoFueraParametros()
        {
            Alumno NuevoAlumno = new Alumno();

            NuevoAlumno.Nombre = "Carmen";
            NuevoAlumno.ApellidoPaterno = "Gomez";
            NuevoAlumno.ApellidoMaterno = "Palacio";
            NuevoAlumno.CorreoElectronico = "Gomez1998@gmail.com";
            NuevoAlumno.Matricula = "S160117312";
            NuevoAlumno.Seccion = "2";
            NuevoAlumno.Bloque = "5";

            int resultado = AlumnoDAO.ResgistrarDatosAlumno(NuevoAlumno);
            Assert.AreEqual(resultado, 1);

        }

        [TestMethod]
        public void RegistrarCoordinadorFuraParametros()
        {
            Coordinador NuevoCoordinador = new Coordinador();

            NuevoCoordinador.Nombre = "Jorge Ocatvio";
            NuevoCoordinador.ApellidoPaterno = "Ocharan";
            NuevoCoordinador.ApellidoMaterno = "Hernández";
            NuevoCoordinador.IDCoordinador = "S900502813";
            NuevoCoordinador.NumeroPersonal = 90050281;

            int resultado = CoordinadorDAO.RegistraDatosCoordinador(NuevoCoordinador);
            Assert.AreEqual(resultado, 1);
        }

        [TestMethod]

        public void RegistrarProyectoFueraParametros()
        {
            Proyecto NuevoProyecto = new Proyecto();

            NuevoProyecto.Nombre = "Sistema De Vialidad Publica";
            NuevoProyecto.IDProyecto = "1009045235";
            NuevoProyecto.ObjetivoGeneral = "Crear un sistema que ayude a los estudiantes a escoger un transporte publico que los lleve a su destino";
            NuevoProyecto.ObjetivoInmediato = "Realizacion de la parte de diseño con respecto al sistema";
            NuevoProyecto.RecursoHumano = "Estudiantes de la licenciatura en ingenieria de software";
            NuevoProyecto.RecursoMaterial = "Equipo de computo de la factultad";
            NuevoProyecto.Responsabilidad = "Realizacion de los modulos indicados por el encargado de la organizacion";
            NuevoProyecto.Metodologia = "Metodologia de prototipo";
            NuevoProyecto.Duracion = 8;
            NuevoProyecto.Calendarizacion = "2019-06-20";
            NuevoProyecto.DescripcionGeneral = "Sistema que ayude al desplazamiento de los alumnos de la Universidad Veracruzana";
            NuevoProyecto.Actividad = "Las propocionadas por el Coordinador";
            NuevoProyecto.Funcion = "Diseño e implementacion";

            int resultado = ProyectoDAO.ResgistrarDatosProyecto(NuevoProyecto);
            Assert.AreEqual(resultado, 1);
        }

        [TestMethod]
        public void ResgitrarOrganizacionFueraParametros()
        {
            Organizacion NuevaOrganizacion = new Organizacion();

            NuevaOrganizacion.Nombre = "LANIA";
            NuevaOrganizacion.IDOrganizacion = "4001783492";
            NuevaOrganizacion.NumeroExterno = 20;
            NuevaOrganizacion.NumeroInterno = 0;
            NuevaOrganizacion.PoblacionAtendida = 100;
            NuevaOrganizacion.Telefono = 8416100;
            NuevaOrganizacion.UsuarioDirecto = "Cora";
            NuevaOrganizacion.UsuarioIndirecto = "Cristina";
            NuevaOrganizacion.Calle = "Rebsamen";
            NuevaOrganizacion.Estado = "Veracruz";
            NuevaOrganizacion.Ciudad = "Xalapa";
            NuevaOrganizacion.CodigoPostal = "91190";
            NuevaOrganizacion.CorreoElectronico = "Lania_Dudas@lania.mx";
            NuevaOrganizacion.IDOrganizacion = "10035501";
            NuevaOrganizacion.Colonia = "Centro";

            int resultado = OrganizacionDAO.ResgistrarDatosOrganizacion(NuevaOrganizacion);
            Assert.AreEqual(resultado, 1);
        }


    }
}

