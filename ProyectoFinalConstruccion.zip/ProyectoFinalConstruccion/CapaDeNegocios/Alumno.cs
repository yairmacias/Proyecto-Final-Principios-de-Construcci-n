﻿using System;

namespace CapaDeNegocios
{
    public class Alumno
    {

    }
}
