﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaDeNegocios
{
    public interface IOrganizacionDAO
    {
        Organizacion RecuperarPorIDOrganizacion(String idOrganizacion);
        Organizacion RecuperarPorNombre(String nombre);
        Organizacion RecuperarPorNumeroInterno(int numeroInterno);
        Organizacion RecuperarPorCalle(String calle);
        Organizacion RecuperarPorNumeroExterno(int numeroExterno);
        Organizacion RecuperarPorPoblacionAtendida(int poblacionAtendida);
        Organizacion RecuperarPorUsuarioDirecto(String usuarioDirecto);
        Organizacion RecuperarPorUsuarioIndirecto(String usuarioIndirecto);
        Organizacion RecuperarPorColonia(String colonia);
        Organizacion RecuperarPorCodigoPostal(String codigoPostal);
        Organizacion RecuperarPorCiudad(String ciudad);
        Organizacion RecuperarPorEstado(String estado);
        Organizacion RecuperarPorTelefono(int telefono);
        Organizacion RecuperarPorCorreoElectronico(String correoElectronico);
        List<Organizacion> GetOrganizacion(String criterio);

    }
}
