﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaDeNegocios
{
    public class GuardarRegistros
    {
        public static int GuardarRegistroAlumno(Alumno alumno)
        {
            return AlumnoDAO.ResgistrarDatosAlumno(alumno);
        }

        public static int GuardarRegistroEncargado(Encargado encargado)
        {
            return EncargadoDAO.ResgistrarDatosEncargado(encargado);
        }

        public static int GuardarRegistroCoordinador(Coordinador coordinador)
        {
            return CoordinadorDAO.RegistraDatosCoordinador(coordinador);
        }

        public static int GuardarRegistroOrganizacion(Organizacion organizacion)
        {
            return OrganizacionDAO.ResgistrarDatosOrganizacion(organizacion);
        }

        public static int GuardarRegistroProyecto(Proyecto proyecto)
        {
            return ProyectoDAO.ResgistrarDatosProyecto(proyecto);
        }
    }
}
