﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using BaseDeDatos;

namespace LogicaDeNegocios
{
    public class EncargadoDAO : IEncargadoDAO
    {
        public Encargado RecuperarPorIDEncargado(string idEncargado)
        {
            Encargado encargado = new Encargado();
            ConexionBaseDeDatos dbManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = dbManager.ObtenerConexion())
            {
                conexion.Open();
                using (SqlCommand command = new SqlCommand("Select * from Encargado where userid=@IDEncargado", conexion))
                {
                    command.Parameters.Add(new SqlParameter("IDEncargado", idEncargado));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        encargado.Nombre = reader["Nombre"].ToString();
                        encargado.ApellidoPaterno = reader["ApellidoPaterno"].ToString();
                        encargado.ApellidoMaterno = reader["ApellidoMaterno"].ToString();
                        encargado.CorreoElectronico = reader["CorreoElectronico"].ToString();
                        encargado.Cargo = reader["Cargo"].ToString();
                    }
                }
                dbManager.ObtenerConexion();
            }
            return encargado;
        }
        public static int ResgistrarDatosEncargado(Encargado encargado)
        {
            ConexionBaseDeDatos dbManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = dbManager.ObtenerConexion())
            {
                try
                {
                    SqlCommand command = new SqlCommand("INSERT INTO Encargado (IDEncargado, Nombre, ApellidoPaterno, ApellidoMaterno, Cargo, CorreoElectronico) Values (@IDEncargado, @Nombre, @ApellidoPaterno, @ApellidoMaterno, @Cargo, @CorreoElectronico)", conexion);
                    command.Parameters.AddWithValue("@IDEncargado", encargado.IDEncargado);
                    command.Parameters.AddWithValue("@Nombre", encargado.Nombre);
                    command.Parameters.AddWithValue("@ApellidoPaterno", encargado.ApellidoPaterno);
                    command.Parameters.AddWithValue("@ApellidoMaterno", encargado.ApellidoMaterno);
                    command.Parameters.AddWithValue("@Cargo", encargado.Cargo);
                    command.Parameters.AddWithValue("@CorreoElectronico", encargado.CorreoElectronico);
                    
                    conexion.Open();

                    int comprobacionDeQuery = command.ExecuteNonQuery();
                    conexion.Close();
                    return comprobacionDeQuery;
                }
                catch (SqlException excepcion)
                {
                    SqlError errorProducido = excepcion.Errors[0];
                    string mensaje = string.Empty;
                    switch (errorProducido.Number)
                    {
                        case 109:
                            mensaje = "Problemas con insert";
                            break;
                        case 110:
                            mensaje = "Más problemas con insert";
                            break;
                        case 113:
                            mensaje = "Problemas con comentarios";
                            break;
                        case 156:
                            mensaje = "Error de sintaxis";
                            break;
                        case 2627:
                            mensaje = "Usuario ya existente";
                            break;
                        case 8152:
                            mensaje = "Longitud del dato sobre pasado";
                            break;
                        default:
                            mensaje = errorProducido.ToString();
                            break;
                    }

                    MessageBox.Show("Error con la base de datos: " + mensaje);
                    return -1;
                }
            }
        }

        public static Boolean InicioDeSesionEncargado(String CorreoElectronico, String IdentificadorPersonal)
        {
            Boolean Validacion = false;
            ConexionBaseDeDatos dbManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = dbManager.ObtenerConexion())
            {
                conexion.Open();
                using (SqlCommand command = new SqlCommand("Select Validacion from Encargado where IDEncargado=@IDEncargado AND CorreoElectronico=@CorreoElectronico", conexion))
                {
                    command.Parameters.Add(new SqlParameter("IDEncargado", IdentificadorPersonal));
                    command.Parameters.Add(new SqlParameter("CorreoElectronico", CorreoElectronico));
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Validacion = reader.GetBoolean(0);
                    }
                    dbManager.CerrarConexion();
                    return Validacion;
                }

            }
        }
        public static DataTable ConsultarEncargado()
        {
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            DataTable DataTable = new DataTable();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {
                try
                {

                    conexion.Open();
                    SqlCommand command = new SqlCommand("ConsultaEncargado", conexion);
                    command.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter Adapter = new SqlDataAdapter(command);

                    Adapter.Fill(DataTable);
                    return DataTable;

                }
                catch (Exception ExcepcionGenerica)
                {
                    MessageBox.Show(ExcepcionGenerica.ToString());
                    return DataTable;

                }
            }
        }
        public static Boolean ActualizarReporte(List<String> idEncargado)
        {
            List<int> respuestas = new List<int>();
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {

                try
                {
                    conexion.Open();

                    for (int i = 0; i < idEncargado.Count; i++)
                    {

                        SqlCommand command = new SqlCommand("update Encargado set Validacion = 1 where IDEncargado=@IDEncargado", conexion);
                        command.Parameters.AddWithValue("@IDEncargado", idEncargado[i]);

                        respuestas.Add(command.ExecuteNonQuery());
                    }

                    conexion.Close();

                    Boolean bandera = true;
                    foreach (int a in respuestas)
                    {
                        if (a == 0)
                        {
                            bandera = false;
                            break;
                        }
                    }

                    return bandera;
                }

                catch (Exception ExcepcionGenerica)
                {
                    System.Windows.MessageBox.Show(ExcepcionGenerica.ToString());
                    return false;
                }
            }
        }

        public Encargado RecuperarPorNombre(string nombre)
        {
            throw new NotImplementedException();
        }

        public Encargado RecuperarPorApellidoPaterno(string apellidoPaterno)
        {
            throw new NotImplementedException();
        }

        public Encargado RecuperarPorApellidoMaterno(string apellidoMaterno)
        {
            throw new NotImplementedException();
        }

        public Encargado RecuperarPorCargo(String cargo)
        {
            throw new NotImplementedException();
        }

        public Encargado RecuperarPorCorreoElectronico(string correoElectronico)
        {
            throw new NotImplementedException();
        }

        public List<Encargado> GetEncargado(string criterio)
        {
            throw new NotImplementedException();
        }
    }
}
