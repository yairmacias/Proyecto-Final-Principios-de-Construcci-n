﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BaseDeDatos;

namespace LogicaDeNegocios
{
    public class EncargadoDAO : IEncargadoDAO
    {
        public Encargado RecuperarPorIDEncargado(string idEncargado)
        {
            Encargado encargado = new Encargado();
            ConexionBaseDeDatos dbManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = dbManager.ObtenerConexion())
            {
                conexion.Open();
                using (SqlCommand command = new SqlCommand("Select * from Encargado where userid=@IDEncargado", conexion))
                {
                    command.Parameters.Add(new SqlParameter("IDEncargado", idEncargado));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        encargado.Nombre = reader["Nombre"].ToString();
                        encargado.ApellidoPaterno = reader["ApellidoPaterno"].ToString();
                        encargado.ApellidoMaterno = reader["ApellidoMaterno"].ToString();
                        encargado.CorreoElectronico = reader["CorreoElectronico"].ToString();
                        encargado.Cargo = reader["Cargo"].ToString();
                    }
                }
                dbManager.ObtenerConexion();
            }
            return encargado;
        }
        public static int ResgistrarDatosEncargado(Encargado encargado)
        {
            ConexionBaseDeDatos dbManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = dbManager.ObtenerConexion())
            {
                try
                {
                    SqlCommand command = new SqlCommand("INSERT INTO Encargado (IDEncargado, Nombre, ApellidoPaterno, ApellidoMaterno, Cargo, CorreoElectronico) Values (@IDEncargado, @Nombre, @ApellidoPaterno, @ApellidoMaterno, @Cargo, @CorreoElectronico)", conexion);
                    command.Parameters.AddWithValue("@IDEncargado", encargado.IDEncargado);
                    command.Parameters.AddWithValue("@Nombre", encargado.Nombre);
                    command.Parameters.AddWithValue("@ApellidoPaterno", encargado.ApellidoPaterno);
                    command.Parameters.AddWithValue("@ApellidoMaterno", encargado.ApellidoMaterno);
                    command.Parameters.AddWithValue("@Cargo", encargado.Cargo);
                    command.Parameters.AddWithValue("@CorreoElectronico", encargado.CorreoElectronico);
                    
                    conexion.Open();

                    int comprobacionDeQuery = command.ExecuteNonQuery();
                    conexion.Close();
                    return comprobacionDeQuery;
                }
                catch(Exception ExcepcionGenerica)
                {
                    System.Windows.MessageBox.Show(ExcepcionGenerica.ToString());
                    return -1;
                }
            }
        }

        public Encargado RecuperarPorNombre(string nombre)
        {
            throw new NotImplementedException();
        }

        public Encargado RecuperarPorApellidoPaterno(string apellidoPaterno)
        {
            throw new NotImplementedException();
        }

        public Encargado RecuperarPorApellidoMaterno(string apellidoMaterno)
        {
            throw new NotImplementedException();
        }

        public Encargado RecuperarPorCargo(String cargo)
        {
            throw new NotImplementedException();
        }

        public Encargado RecuperarPorCorreoElectronico(string correoElectronico)
        {
            throw new NotImplementedException();
        }

        public List<Encargado> GetEncargado(string criterio)
        {
            throw new NotImplementedException();
        }
    }
}
