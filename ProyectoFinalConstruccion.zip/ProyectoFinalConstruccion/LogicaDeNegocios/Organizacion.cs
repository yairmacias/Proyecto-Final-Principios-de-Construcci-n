﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaDeNegocios
{
    public class Organizacion
    {
        public String IDOrganizacion { get; set; }
        public String Nombre { get; set; }
        public int NumeroInterno { get; set; }
        public String Calle { get; set; }
        public int NumeroExterno { get; set; }
        public int PoblacionAtendida { get; set; }
        public String UsuarioDirecto { get; set; }
        public String UsuarioIndirecto { get; set; }
        public String Colonia { get; set; }
        public String CodigoPostal { get; set; }
        public String Ciudad { get; set; }       
        public String Estado { get; set; }
        public int Telefono { get; set; }
        public String CorreoElectronico { get; set; }

        public Organizacion(String IDOrganizacion, String Nombre, int NumeroInterno, String Calle, int NumeroExterno, int PoblacionAtendida, 
                            String UsuarioDirecto, String UsuarioIndirecto, String Colonia, String CodigoPostal, String Ciudad, String Estado, int Telefono, String CorreoElectronico)
        {
            this.IDOrganizacion = IDOrganizacion;
            this.Nombre = Nombre;
            this.NumeroInterno = NumeroInterno;
            this.Calle = Calle;
            this.NumeroExterno = NumeroExterno;
            this.PoblacionAtendida = PoblacionAtendida;
            this.UsuarioDirecto = UsuarioDirecto;
            this.UsuarioIndirecto = UsuarioIndirecto;
            this.Colonia = Colonia;
            this.CodigoPostal = CodigoPostal;
            this.Ciudad = Ciudad;            
            this.Estado = Estado;
            this.Telefono = Telefono;
            this.CorreoElectronico = CorreoElectronico;
        }

        public Organizacion()
        {

        }
    }
}
