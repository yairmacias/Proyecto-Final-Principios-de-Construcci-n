﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using BaseDeDatos;
using System.Data;
using System.Windows;

namespace LogicaDeNegocios
{
    public class AlumnoDAO : IAlumnoDAO
    {
        public Alumno RecuperarPorMatricula(string matricula)
        {
            Alumno alumno = new Alumno();
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {
                conexion.Open();
                using (SqlCommand command = new SqlCommand("Select * from Alumno where userid=@matricula", conexion))
                {
                    command.Parameters.Add(new SqlParameter("Matricula", matricula));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        alumno.Nombre = reader["Nombre"].ToString();
                        alumno.ApellidoPaterno = reader["ApellidoPaterno"].ToString();
                        alumno.ApellidoMaterno = reader["ApellidoMaterno"].ToString();
                        alumno.CorreoElectronico = reader["CorreoElectronico"].ToString();
                        alumno.Seccion = reader["Seccion"].ToString();
                        alumno.Bloque = reader["Bloque"].ToString();
                    }
                }
                DBManager.CerrarConexion();
            }
            return alumno;
        }

        public static int ResgistrarDatosAlumno(Alumno alumno)
        {
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {

                try
                {
                    conexion.Open();
                    SqlCommand command = new SqlCommand("INSERT INTO Alumno (Matricula, Nombre, ApellidoPaterno, ApellidoMaterno, CorreoElectronico, Bloque, Seccion) Values (@Matricula,@Nombre, @ApellidoPaterno, @ApellidoMaterno, @CorreoElectronico, @Bloque, @Seccion)", conexion);
                    command.Parameters.AddWithValue("@Matricula", alumno.Matricula);
                    command.Parameters.AddWithValue("@Nombre", alumno.Nombre);
                    command.Parameters.AddWithValue("@ApellidoPaterno", alumno.ApellidoPaterno);
                    command.Parameters.AddWithValue("@ApellidoMaterno", alumno.ApellidoMaterno);
                    command.Parameters.AddWithValue("@CorreoElectronico", alumno.CorreoElectronico);
                    command.Parameters.AddWithValue("@Bloque", alumno.Bloque);
                    command.Parameters.AddWithValue("@Seccion", alumno.Seccion);

                    int comprobacionDeQuery = command.ExecuteNonQuery();
                    conexion.Close();
                    return comprobacionDeQuery;
                }
              
                catch (Exception ExcepcionGenerica)
                {
                    System.Windows.MessageBox.Show(ExcepcionGenerica.ToString());
                    return -1;
                }



            }
        }

        public static DataTable ConsultarAlumnoCarrera(String matricula)
        {
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            DataTable DataTable = new DataTable();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {

                try
                {
                     
                    conexion.Open();
                    SqlCommand command = new SqlCommand("consultaAlumno", conexion);
                    command.CommandType = CommandType.StoredProcedure;
                    //.Parameters.Add("@Matricula", SqlDbType.VarChar, 9);
                    command.Parameters.AddWithValue("@Matricula", matricula);

                    SqlDataAdapter da = new SqlDataAdapter(command);

                     da.Fill(DataTable);
                    return DataTable;

                }
                catch(Exception ExcepcionGenerica)
                {
                    return DataTable;
                    MessageBox.Show(ExcepcionGenerica.ToString());

                }


            }
        }

        public static List<DataTable> ConsultarAlumnoEncargado()
        {
            List<DataTable> arregloTablas = new List<DataTable>();
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            DataTable dt1 = new DataTable();
            DataTable dt2 = new DataTable();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {
                try
                {
                   

                    SqlCommand command = new SqlCommand("ConsultaEncargado", conexion);
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter(command);
                    conexion.Open();
                    da.Fill(dt1);
                    arregloTablas.Add(dt1);

                    command = new SqlCommand("ConsultarAlumno", conexion);
                    da = new SqlDataAdapter(command);
                    da.Fill(dt2);
                    arregloTablas.Add(dt2);

                    return arregloTablas;

                }
                catch (Exception ExcepcionGenerica)
                {
                    return arregloTablas;
                    MessageBox.Show(ExcepcionGenerica.ToString());

                }


            }
        }

        public static Boolean ActualizarReporte(List<String> matriculas)
         {
            List<int> respuestas = new List<int>();
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {

                try
                {
                    conexion.Open();

                    for (int i = 0; i < matriculas.Count; i++)
                    {

                        SqlCommand command = new SqlCommand("update Alumno set Validado = 1 where Matricula=@Matricula", conexion);
                        command.Parameters.AddWithValue("@Matricula", matriculas[i]);

                        respuestas.Add(command.ExecuteNonQuery());
                    }

                    conexion.Close();

                    Boolean bandera = true;
                    foreach (int a in respuestas)
                    {
                        if (a == 0)
                        {
                            bandera = false;
                            break;
                        }
                    }

                    return bandera;
                }

                catch (Exception ExcepcionGenerica)
                {
                    System.Windows.MessageBox.Show(ExcepcionGenerica.ToString());
                    return false;
                }
            }
        }

        public Alumno RecuperarPorNombre(String nombre)
        {
            throw new NotImplementedException();
        }

        public Alumno RecuperarPorApellidoPaterno(String apellidoPaterno)
        {
            throw new NotImplementedException();
        }

        public Alumno RecuperarPorApellidoMaterno(String apellidoMaterno)
        {
            throw new NotImplementedException();
        }

        public Alumno RecuperarPorCorreoElectronico(String correoElectronico)
        {
            throw new NotImplementedException();
        }
        public Alumno RecuperarPorBloque(String bloque)
        {
            throw new NotImplementedException();
        }

        public Alumno RecuperarPorSeccion(String seccion)
        {
            throw new NotImplementedException();
        }

        public List<Alumno> GetAlumno(String criterio)
        {
            throw new NotImplementedException();
        }


    }
}
