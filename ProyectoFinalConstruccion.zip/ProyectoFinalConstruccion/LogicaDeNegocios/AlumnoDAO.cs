﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using BaseDeDatos;
using System.Data;
using System.Windows;

namespace LogicaDeNegocios
{
    public class AlumnoDAO : IAlumnoDAO
    {
        public Alumno RecuperarPorMatricula(string matricula)
        {
            Alumno alumno = new Alumno();
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {
                conexion.Open();
                using (SqlCommand command = new SqlCommand("Select * from Alumno where userid=@matricula", conexion))
                {
                    command.Parameters.Add(new SqlParameter("Matricula", matricula));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        alumno.Nombre = reader["Nombre"].ToString();
                        alumno.ApellidoPaterno = reader["ApellidoPaterno"].ToString();
                        alumno.ApellidoMaterno = reader["ApellidoMaterno"].ToString();
                        alumno.CorreoElectronico = reader["CorreoElectronico"].ToString();
                        alumno.Seccion = reader["Seccion"].ToString();
                        alumno.Bloque = reader["Bloque"].ToString();
                    }
                }
                DBManager.CerrarConexion();
            }
            return alumno;
        }

        public static int ResgistrarDatosAlumno(Alumno alumno)
        {
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {

                try
                {
                    conexion.Open();
                    SqlCommand command = new SqlCommand("INSERT INTO Alumno (Matricula, Nombre, ApellidoPaterno, ApellidoMaterno, CorreoElectronico, Bloque, Seccion) Values (@Matricula,@Nombre, @ApellidoPaterno, @ApellidoMaterno, @CorreoElectronico, @Bloque, @Seccion)", conexion);
                    command.Parameters.AddWithValue("@Matricula", alumno.Matricula);
                    command.Parameters.AddWithValue("@Nombre", alumno.Nombre);
                    command.Parameters.AddWithValue("@ApellidoPaterno", alumno.ApellidoPaterno);
                    command.Parameters.AddWithValue("@ApellidoMaterno", alumno.ApellidoMaterno);
                    command.Parameters.AddWithValue("@CorreoElectronico", alumno.CorreoElectronico);
                    command.Parameters.AddWithValue("@Bloque", alumno.Bloque);
                    command.Parameters.AddWithValue("@Seccion", alumno.Seccion);

                    int comprobacionDeQuery = command.ExecuteNonQuery();
                    conexion.Close();
                    return comprobacionDeQuery;
                }

                catch (SqlException excepcion)
                {
                    SqlError errorProducido = excepcion.Errors[0];
                    string mensaje = string.Empty;
                    switch (errorProducido.Number)
                    {
                        case 109:
                            mensaje = "Problemas con insert";
                            break;
                        case 110:
                            mensaje = "Más problemas con insert";
                            break;
                        case 113:
                            mensaje = "Problemas con comentarios";
                            break;
                        case 156:
                            mensaje = "Error de sintaxis";
                            break;
                        case 2627:
                            mensaje = "Usuario ya existente";
                                break;
                        case 8152:
                            mensaje = "Longitud del dato sobre pasado";
                            break;
                        default:
                            mensaje = errorProducido.ToString();
                            break;
                    }

                    MessageBox.Show("Error con la base de datos: " + mensaje);
                    return -1;
                }
            }
        }

         public static Boolean InicioDeSesionAlumno(String CorreoElectronico, String Matricula)
        {
            Boolean Validacion = false;
            ConexionBaseDeDatos dbManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = dbManager.ObtenerConexion())
            {
                conexion.Open();
                using (SqlCommand command = new SqlCommand("Select Validacion from Alumno where Matricula=@Matricula AND CorreoElectronico=@CorreoElectronico", conexion))
                {
                    command.Parameters.Add(new SqlParameter("Matricula", Matricula));
                    command.Parameters.Add(new SqlParameter("CorreoElectronico", CorreoElectronico));
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Validacion = reader.GetBoolean(0);
                    }
                    dbManager.CerrarConexion();
                    return Validacion;
                }

            }
        }

        public static DataTable ConsultarAlumno()
        {
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            DataTable DataTable = new DataTable();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {
                try
                {

                    conexion.Open();
                    SqlCommand command = new SqlCommand("ConsultarAlumno", conexion);
                    command.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter Adapter = new SqlDataAdapter(command);

                    Adapter.Fill(DataTable);
                    return DataTable;

                }
                catch (Exception ExcepcionGenerica)
                {
                    MessageBox.Show(ExcepcionGenerica.ToString());
                    return DataTable;

                }
            }
        }

        public static Boolean ActualizarReporte(List<String> matricula)
        {
            List<int> respuestas = new List<int>();
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {

                try
                {
                    conexion.Open();

                    for (int i = 0; i < matricula.Count; i++)
                    {

                        SqlCommand command = new SqlCommand("update Alumno set Validacion = 1 where Matricula=@Matricula", conexion);
                        command.Parameters.AddWithValue("@Matricula", matricula[i]);

                        respuestas.Add(command.ExecuteNonQuery());
                    }

                    conexion.Close();

                    Boolean bandera = true;
                    foreach (int validacion in respuestas)
                    {
                        if (validacion == 0)
                        {
                            bandera = false;
                            break;
                        }
                    }

                    return bandera;
                }

                catch (Exception ExcepcionGenerica)
                {
                    System.Windows.MessageBox.Show(ExcepcionGenerica.ToString());
                    return false;
                }
            }
        }

        public Alumno RecuperarPorNombre(String nombre)
        {
            throw new NotImplementedException();
        }

        public Alumno RecuperarPorApellidoPaterno(String apellidoPaterno)
        {
            throw new NotImplementedException();
        }

        public Alumno RecuperarPorApellidoMaterno(String apellidoMaterno)
        {
            throw new NotImplementedException();
        }

        public Alumno RecuperarPorCorreoElectronico(String correoElectronico)
        {
            throw new NotImplementedException();
        }
        public Alumno RecuperarPorBloque(String bloque)
        {
            throw new NotImplementedException();
        }

        public Alumno RecuperarPorSeccion(String seccion)
        {
            throw new NotImplementedException();
        }

        public List<Alumno> GetAlumno(String criterio)
        {
            throw new NotImplementedException();
        }


    }
}
