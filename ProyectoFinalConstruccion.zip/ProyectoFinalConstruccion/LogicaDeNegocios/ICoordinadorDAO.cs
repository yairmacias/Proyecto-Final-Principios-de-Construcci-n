﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaDeNegocios
{
    interface ICoordinadorDAO
    {

        Coordinador RecuperarPorNombre(String nombre);
        Coordinador RecuperarPorIdentificador(String idCoordinador); 
        Coordinador RecuperarPorApellidoPaterno(String apellidoPaterno);
        Coordinador RecuperarPorApellidoMaterno(String apellidoMaterno);
        Coordinador RecuperarPorCorreoElectronico(String correoElectronico);
        Coordinador RecuperarPorNumeroPersonal(int numeroPersonal);
        List<Coordinador> GetCoordinador(String criterio);
    }
}
