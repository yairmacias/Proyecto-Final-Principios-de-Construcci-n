﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using BaseDeDatos;


namespace LogicaDeNegocios
{
   public class ValidacionDeInterfaz
    {
        public static Boolean ValidarTextbox(UIElementCollection ElementoColeccion)
        {
            Boolean bandera = false;

            foreach (UIElement ElementoInterfaz in ElementoColeccion)
            {
                if (ElementoInterfaz is TextBox TextBox)
                {
                    if (TextBox.Text == "")
                    {
                        bandera = false;
                        break;
                    }
                    else
                    { bandera = true; }
                }
            }

            return bandera;
        }

        public static Boolean ValidarCamposNumericos(object sender, KeyEventArgs e)
        {
            if (e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)
                e.Handled = false;
            else
                e.Handled = true;

            return e.Handled;
        }


        public static Boolean ValidarCamposCaracter(object sender, TextCompositionEventArgs e)
        {
                int ascci = Convert.ToInt32(Convert.ToChar(e.Text));

                if (ascci >= 65 && ascci <= 90 || ascci >= 97 && ascci <= 122)

                    e.Handled = false;

                else e.Handled = true;

                return e.Handled;   
        }

        public static Boolean ValidarCuentaCoordinador(int NumeroPersonal, String IdentificadorPersonal)
        {
            return CoordinadorDAO.InicioDeSesionCoordinador(NumeroPersonal, IdentificadorPersonal);
        }

        public static Boolean ValidarCuentaAlumno(String CorreoElectronico, String Matricula)
        {
            return AlumnoDAO.InicioDeSesionAlumno(CorreoElectronico, Matricula);
        }

        public static Boolean ValidarCuentaEncargado(String CorreoElectronico, String IdentificadorPersonal)
        {
            return EncargadoDAO.InicioDeSesionEncargado(CorreoElectronico, IdentificadorPersonal);
        }

    }
}
