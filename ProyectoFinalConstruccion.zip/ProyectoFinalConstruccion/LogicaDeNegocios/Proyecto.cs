﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaDeNegocios
{
    public class Proyecto
    {
        public String IDProyecto { get; set; }
        public String Actividad { get; set; }
        public String Calendarizacion { get; set; }
        public String DescripcionGeneral { get; set; }
        public float Duracion { get; set; }
        public String Funcion { get; set; }
        public String Metodologia { get; set; }
        public String Nombre { get; set; }
        public String ObjetivoGeneral { get; set; }
        public String ObjetivoInmediato { get; set; }
        public String RecursoHumano { get; set; }
        public String RecursoMaterial { get; set; }
        public String Responsabilidad { get; set; }

        public Proyecto(String IDProyecto, String Actividad, String Calendarizacion, String DescripcionGeneral, float Duracion, 
            String Funcion, String Metodologia, String Nombre, String ObjetivoGeneral, String ObjetivoInmediato, 
            String RecursoHumano, String Responsabilidad, String RecursoMaterial)
        {
            this.IDProyecto = IDProyecto;
            this.Actividad = Actividad;
            this.Calendarizacion = Calendarizacion;
            this.DescripcionGeneral = DescripcionGeneral;
            this.Funcion = Funcion;
            this.Metodologia = Metodologia;
            this.Nombre = Nombre;
            this.ObjetivoGeneral = ObjetivoGeneral;
            this.ObjetivoInmediato = ObjetivoInmediato;
            this.RecursoHumano = RecursoHumano;
            this.Responsabilidad = Responsabilidad;
            this.Duracion = Duracion;
            this.RecursoMaterial = RecursoMaterial;

        }

        public Proyecto()
        {

        }
    }
}
