﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using BaseDeDatos;

namespace LogicaDeNegocios
{
    public class ProyectoDAO : IProyectoDAO
    {
        public Proyecto RecuperarPorIDProyecto(string idProyecto)
        {
            Proyecto proyecto = new Proyecto();
            ConexionBaseDeDatos dbManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = dbManager.ObtenerConexion())
            {
                conexion.Open();
                using (SqlCommand command = new SqlCommand("Select * from Proyecto where userid=@IDProyecto", conexion))
                {
                    command.Parameters.Add(new SqlParameter("IDProyecto", idProyecto));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        proyecto.Nombre = reader["Nombre"].ToString();
                        proyecto.Actividad = reader["Actividad"].ToString();
                        proyecto.Calendarizacion = reader["Calendarizacion"].ToString();
                        proyecto.DescripcionGeneral = reader["DescripcionGeneral"].ToString();
                        proyecto.Duracion = (float)reader["Duracion"];
                        proyecto.Funcion = reader["Funcion"].ToString();
                        proyecto.Metodologia = reader["Metodologia"].ToString();
                        proyecto.ObjetivoGeneral = reader["ObjetivoGeneral"].ToString();
                        proyecto.ObjetivoInmediato = reader["ObjetivoInmediato"].ToString();
                        proyecto.RecursoHumano = reader["RecursoHumano"].ToString();
                        proyecto.RecursoMaterial = reader["RecursoMaterial"].ToString();
                        proyecto.Responsabilidad = reader["Responsabilidad"].ToString();
                    }
                }
                dbManager.CerrarConexion();
            }
            return proyecto;
        }
        public static int ResgistrarDatosProyecto(Proyecto proyecto)
        {
            ConexionBaseDeDatos dbManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = dbManager.ObtenerConexion())
            {

                try
                {
                    SqlCommand command = new SqlCommand("INSERT INTO Proyecto(IDProyecto, Nombre, DescripcionGeneral, ObjetivoInmediato, ObjetivoGeneral, RecursosHumanos, Actividades, Reponsabilidades, Calendarizacion, Funciones, Duracion, Materiales, Metodologia) " +
                                    "Values (@IDProyecto, @Nombre, @DescripcionGeneral, @ObjetivoInmediato, @ObjetivoGeneral, @RecursoHumano, @Actividad, @Reponsabilidades, @Calendarizacion, @Funcion, @Duracion, @RecursoMaterial, @Metodologia)", conexion);
                    command.Parameters.AddWithValue("@IDProyecto", proyecto.IDProyecto);
                    command.Parameters.AddWithValue("@Nombre", proyecto.Nombre);
                    command.Parameters.AddWithValue("@DescripcionGeneral", proyecto.DescripcionGeneral);
                    command.Parameters.AddWithValue("@ObjetivoInmediato", proyecto.ObjetivoInmediato);
                    command.Parameters.AddWithValue("@ObjetivoGeneral", proyecto.ObjetivoGeneral);
                    command.Parameters.AddWithValue("@RecursoHumano", proyecto.RecursoHumano);
                    command.Parameters.AddWithValue("@Actividad", proyecto.Actividad);
                    command.Parameters.AddWithValue("@Reponsabilidades", proyecto.Responsabilidad);
                    command.Parameters.AddWithValue("@Calendarizacion", proyecto.Calendarizacion);
                    command.Parameters.AddWithValue("@Funcion", proyecto.Funcion);
                    command.Parameters.AddWithValue("@Duracion", proyecto.Duracion);
                    command.Parameters.AddWithValue("@RecursoMaterial", proyecto.RecursoMaterial);
                    command.Parameters.AddWithValue("@Metodologia", proyecto.Metodologia);
                    conexion.Open();

                    int comprobacionDeQuery = command.ExecuteNonQuery();
                    conexion.Close();
                    return comprobacionDeQuery;

                }
                catch (SqlException excepcion)
                {
                    SqlError errorProducido = excepcion.Errors[0];
                    string mensaje = string.Empty;
                    switch (errorProducido.Number)
                    {
                        case 109:
                            mensaje = "Problemas con insert";
                            break;
                        case 110:
                            mensaje = "Más problemas con insert";
                            break;
                        case 113:
                            mensaje = "Problemas con comentarios";
                            break;
                        case 156:
                            mensaje = "Error de sintaxis";
                            break;
                        case 2627:
                            mensaje = "Usuario ya existente";
                            break;
                        case 8152:
                            mensaje = "Longitud del dato sobre pasado";
                            break;
                        default:
                            mensaje = errorProducido.ToString();
                            break;
                    }

                    MessageBox.Show("Error con la base de datos: " + mensaje);
                    return -1;
                }
            }
        }
        public static DataTable ConsultarProyecto()
        {
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            DataTable DataTable = new DataTable();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
                try
                {
                    conexion.Open();
                    SqlCommand command = new SqlCommand("ConsultarProyecto", conexion);
                    command.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter Adapter = new SqlDataAdapter(command);

                    Adapter.Fill(DataTable);
                    return DataTable;
                }
                catch (Exception ExcepcionGenerica)
                {
                    MessageBox.Show(ExcepcionGenerica.ToString());
                    return DataTable;
                    
                }
        }

        public static Boolean ActualizarReporte(List<String> IDProyecto)
        {
            List<int> respuestas = new List<int>();
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {

                try
                {
                    conexion.Open();

                    for (int i = 0; i < IDProyecto.Count; i++)
                    {

                        SqlCommand command = new SqlCommand("update Proyecto set Validacion = 1 where IDProyecto=@IDProyecto", conexion);
                        command.Parameters.AddWithValue("@IDProyecto", IDProyecto[i]);

                        respuestas.Add(command.ExecuteNonQuery());
                    }

                    conexion.Close();

                    Boolean bandera = true;
                    foreach (int a in respuestas)
                    {
                        if (a == 0)
                        {
                            bandera = false;
                            break;
                        }
                    }

                    return bandera;
                }

                catch (Exception ExcepcionGenerica)
                {
                    System.Windows.MessageBox.Show(ExcepcionGenerica.ToString());
                    return false;
                }
            }
        }

        public Proyecto RecuperarPorActividad(String actividad)
        {
            throw new NotImplementedException();
        }

        public Proyecto RecuperarPorCalendarizacion(String calendarizacion)
        {
            throw new NotImplementedException();
        }


        public Proyecto RecuperarPorDuracion(float duracion)
        {
            throw new NotImplementedException();
        }

        public Proyecto RecuperarPorFuncion(String funcion)
        {
            throw new NotImplementedException();
        }

        public Proyecto RecuperarPorMetodologia(String metdologia)
        {
            throw new NotImplementedException();
        }

        public Proyecto RecuperarPorNombre(String nombre)
        {
            throw new NotImplementedException();
        }

        public Proyecto RecuperarPorObjetivoGeneral(String objetivoGeneral)
        {
            throw new NotImplementedException();
        }

        public Proyecto RecuperarPorObjetivoInmediato(String objetivoImediato)
        {
            throw new NotImplementedException();
        }

        public Proyecto RecuperarPorRecursoHumano(String recursoHumano)
        {
            throw new NotImplementedException();
        }


        public Proyecto RecuperarPorResponsabilidad(String responsabilidad)
        {
            throw new NotImplementedException();
        }

        public Proyecto RecuperarPorRecursosMateriales(String recursosMateriales)
        {
            throw new NotImplementedException();
        }

        public Proyecto RecuperarPorDescripcionGeneral(String descripcionGeneral)
        {
            throw new NotImplementedException();
        }

        public List<Proyecto> GetProyecto(String criterio)
        {
            throw new NotImplementedException();
        }

    }
}
