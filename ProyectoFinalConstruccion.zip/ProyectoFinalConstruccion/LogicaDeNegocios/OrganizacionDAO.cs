﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BaseDeDatos;
using System.Data.SqlClient;
using System.Data;
using System.Windows;

namespace LogicaDeNegocios
{
    public class OrganizacionDAO : IOrganizacionDAO
    {
        public Organizacion RecuperarPorIDOrganizacion(string idOrganizacion)
        {
            Organizacion organizacion = new Organizacion();
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {
                conexion.Open();
                using (SqlCommand command = new SqlCommand("Select * from Organizacion where userid=@IDOrganizacion", conexion))
                {
                    command.Parameters.Add(new SqlParameter("IDOrganizacion", idOrganizacion));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        organizacion.Nombre = reader["Nombre"].ToString();
                        organizacion.NumeroInterno = (int)reader["NumeroInterno"];
                        organizacion.Calle = reader["Calle"].ToString();
                        organizacion.NumeroExterno = (int)reader["NumeroExterno"];
                        organizacion.PoblacionAtendida = (int)reader["PoblacionAtendida"];
                        organizacion.UsuarioDirecto = reader["UsuarioDirecto"].ToString();
                        organizacion.UsuarioIndirecto = reader["UsuarioIndirecto"].ToString();
                        organizacion.CodigoPostal = reader["CodigoPostal"].ToString();
                        organizacion.Colonia = reader["Colonia"].ToString();
                        organizacion.Ciudad = reader["Ciudad"].ToString();
                        organizacion.Estado = reader["Estado"].ToString();
                        organizacion.Telefono = (int)reader["Telefono"];
                        organizacion.CorreoElectronico = reader["CorreroElectronico"].ToString();
                       
                    }
                }
                DBManager.CerrarConexion();
            }
            return organizacion;
        }

        public static int ResgistrarDatosOrganizacion(Organizacion organizacion)
        {
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {

                try
                    
                {
                    conexion.Open();
                    SqlCommand command = new SqlCommand("INSERT INTO Organizacion(IDOrganizacion, Nombre, NumeroInterno, Calle, NumeroExterno, PoblacionAtendida, UsuarioDirecto, UsuarioIndirecto, Colonia, CodigoPostal, Ciudad, Estado, Telefono, CorreoElectronico) Values (@IDOrganizacion, @Nombre, @NumeroInterno, @Calle, @NumeroExterno, @PoblacionAtendida, @UsuarioDirecto, @UsuarioIndirecto, @Colonia, @CodigoPostal, @Ciudad,  @Estado, @Telefono, @CorreoElectronico)", conexion);
                    command.Parameters.AddWithValue("IDOrganizacion", organizacion.IDOrganizacion);
                    command.Parameters.AddWithValue("@Nombre", organizacion.Nombre);
                    command.Parameters.AddWithValue("@NumeroInterno", organizacion.NumeroInterno);
                    command.Parameters.AddWithValue("@Calle", organizacion.Calle);
                    command.Parameters.AddWithValue("@NumeroExterno", organizacion.NumeroExterno);
                    command.Parameters.AddWithValue("@PoblacionAtendida", organizacion.PoblacionAtendida);
                    command.Parameters.AddWithValue("@UsuarioDirecto", organizacion.UsuarioDirecto);
                    command.Parameters.AddWithValue("@UsuarioIndirecto", organizacion.UsuarioIndirecto);
                    command.Parameters.AddWithValue("@Colonia", organizacion.Colonia);
                    command.Parameters.AddWithValue("@CodigoPostal", organizacion.CodigoPostal);
                    command.Parameters.AddWithValue("@Ciudad", organizacion.Ciudad);
                    command.Parameters.AddWithValue("@Estado", organizacion.Estado);
                    command.Parameters.AddWithValue("@Telefono", organizacion.Telefono);
                    command.Parameters.AddWithValue("@CorreoElectronico", organizacion.CorreoElectronico);

                    int comprobacionDeQuery = command.ExecuteNonQuery();
                    conexion.Close();
                    return comprobacionDeQuery;
                }
                catch (SqlException excepcion)
                {
                    SqlError errorProducido = excepcion.Errors[0];
                    string mensaje = string.Empty;
                    switch (errorProducido.Number)
                    {
                        case 109:
                            mensaje = "Problemas con insert";
                            break;
                        case 110:
                            mensaje = "Más problemas con insert";
                            break;
                        case 113:
                            mensaje = "Problemas con comentarios";
                            break;
                        case 156:
                            mensaje = "Error de sintaxis";
                            break;
                        case 2627:
                            mensaje = "Usuario ya existente";
                            break;
                        case 8152:
                            mensaje = "Longitud del dato sobre pasado";
                            break;
                        default:
                            mensaje = errorProducido.ToString();
                            break;
                    }

                    MessageBox.Show("Error con la base de datos: " + mensaje);
                    return -1;
                }
            }
        }

        public static DataTable ConsultarOrganizacion()
        {
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            DataTable DataTable = new DataTable();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {
                try
                {

                    conexion.Open();
                    SqlCommand command = new SqlCommand("ConsultaOrganizacion", conexion);
                    command.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter Adapter = new SqlDataAdapter(command);

                    Adapter.Fill(DataTable);
                    return DataTable;

                }
                catch(Exception ExcepcionGenerica)
                {
                    MessageBox.Show(ExcepcionGenerica.ToString());
                    return DataTable;
                    
                }
            }
        }
        public static Boolean ActualizarReporte(List<String> IDOrganizacion)
        {
            List<int> respuestas = new List<int>();
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {

                try
                {
                    conexion.Open();

                    for (int i = 0; i < IDOrganizacion.Count; i++)
                    {

                        SqlCommand command = new SqlCommand("update Organizacion set Validacion = 1 where IDOrganizacion=@IDOrganizacion", conexion);
                        command.Parameters.AddWithValue("@IDOrganizacion", IDOrganizacion[i]);

                        respuestas.Add(command.ExecuteNonQuery());
                    }

                    conexion.Close();

                    Boolean bandera = true;
                    foreach (int a in respuestas)
                    {
                        if (a == 0)
                        {
                            bandera = false;
                            break;
                        }
                    }

                    return bandera;
                }

                catch (Exception ExcepcionGenerica)
                {
                    System.Windows.MessageBox.Show(ExcepcionGenerica.ToString());
                    return false;
                }
            }
        }

        public Organizacion RecuperarPorNombre(string nombre)
        {
            throw new NotImplementedException();
        }

        public Organizacion RecuperarPorNumeroInterno(int numeroInterno)
        {
            throw new NotImplementedException();
        }

        public Organizacion RecuperarPorCalle(string calle)
        {
            throw new NotImplementedException();
        }

        public Organizacion RecuperarPorNumeroExterno(int numeroExterno)
        {
            throw new NotImplementedException();
        }

        public Organizacion RecuperarPorPoblacionAtendida(int poblacionAtendida)
        {
            throw new NotImplementedException();
        }

        public Organizacion RecuperarPorUsuarioDirecto(string usuarioDirecto)
        {
            throw new NotImplementedException();
        }

        public Organizacion RecuperarPorUsuarioIndirecto(string usuarioIndirecto)
        {
            throw new NotImplementedException();
        }

        public Organizacion RecuperarPorCiudad(string ciudad)
        {
            throw new NotImplementedException();
        }

        public Organizacion RecuperarPorCodigoPostal(string codigoPostal)
        {
            throw new NotImplementedException();
        }

        public Organizacion RecuperarPorColonia(string calle)
        {
            throw new NotImplementedException();
        }

        public Organizacion RecuperarPorEstado(string calle)
        {
            throw new NotImplementedException();
        }

        public Organizacion RecuperarPorTelefono(int calle)
        {
            throw new NotImplementedException();
        }

        public Organizacion RecuperarPorCorreoElectronico(string correElectronico)
        {
            throw new NotImplementedException();
        }

        public List<Organizacion> GetOrganizacion(string criterio)
        {
            throw new NotImplementedException();
        }
    }
}
