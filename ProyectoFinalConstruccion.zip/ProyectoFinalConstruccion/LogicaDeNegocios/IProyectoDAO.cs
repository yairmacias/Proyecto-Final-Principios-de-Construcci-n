﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaDeNegocios
{
   public  interface IProyectoDAO
    {
        Proyecto RecuperarPorIDProyecto(String idProyecto);
        Proyecto RecuperarPorActividad(String actividad);
        Proyecto RecuperarPorCalendarizacion(String calendarizacion);
        Proyecto RecuperarPorDuracion(float duracion);
        Proyecto RecuperarPorFuncion(String funcion);
        Proyecto RecuperarPorMetodologia(String metodologia);
        Proyecto RecuperarPorNombre(String nombre);
        Proyecto RecuperarPorObjetivoGeneral(String objetivoGeneral);
        Proyecto RecuperarPorObjetivoInmediato(String objetivoInmediato);
        Proyecto RecuperarPorRecursoHumano(String recursoHumano);
        Proyecto RecuperarPorDescripcionGeneral(String descripcionGeneral);
        Proyecto RecuperarPorRecursosMateriales(String recursosMateriales);
        Proyecto RecuperarPorResponsabilidad(String reponsabilidad);
        List<Proyecto> GetProyecto(String criterio);
       


    }
}
