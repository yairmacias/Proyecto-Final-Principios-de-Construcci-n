﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using BaseDeDatos;
using System.Windows;

namespace LogicaDeNegocios
{
     public class CoordinadorDAO : ICoordinadorDAO
    {
        public Coordinador RecuperarPorIdentificador(string idCoordinador)
        {
            Coordinador coordinador = new Coordinador();
            ConexionBaseDeDatos dbManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = dbManager.ObtenerConexion())
            {
                conexion.Open();
                using (SqlCommand command = new SqlCommand("Select * from Coordinador where userid=@IDCoordinador", conexion))
                {
                    command.Parameters.Add(new SqlParameter("IDCoordinador", idCoordinador));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        coordinador.Nombre = reader["Nombre"].ToString();
                        coordinador.ApellidoPaterno = reader["ApellidoPaterno"].ToString();
                        coordinador.ApellidoMaterno = reader["ApellidoMaterno"].ToString();
                        coordinador.NumeroPersonal = (int)reader["NumeroPersonal"];
                    }
                }
                dbManager.CerrarConexion();
            }
            return coordinador;


        }
        public static int RegistraDatosCoordinador(Coordinador coordinador)
        {
            ConexionBaseDeDatos dbManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = dbManager.ObtenerConexion())
            {
                try
                {
                    SqlCommand command = new SqlCommand("INSERT INTO Coordinador (IDCoordinador, Nombre, ApellidoPaterno, ApellidoMaterno, NumeroPersonal) Values (@IDCoordinador, @Nombre, @ApellidoPaterno, @ApellidoMaterno, @NumeroPersonal)", conexion);
                    command.Parameters.AddWithValue("@IDCoordinador", coordinador.IDCoordinador);
                    command.Parameters.AddWithValue("@Nombre", coordinador.Nombre);
                    command.Parameters.AddWithValue("@ApellidoPaterno", coordinador.ApellidoPaterno);
                    command.Parameters.AddWithValue("@ApellidoMaterno", coordinador.ApellidoMaterno);
                    command.Parameters.AddWithValue("@NumeroPersonal", coordinador.NumeroPersonal);
                    conexion.Open();

                    int comprobacionDeQuery = command.ExecuteNonQuery();
                    dbManager.CerrarConexion();
                    return comprobacionDeQuery;
                }
                catch (SqlException excepcion)
                {
                    SqlError errorProducido = excepcion.Errors[0];
                    string mensaje = string.Empty;
                    switch (errorProducido.Number)
                    {
                        case 109:
                            mensaje = "Problemas con insert";
                            break;
                        case 110:
                            mensaje = "Más problemas con insert";
                            break;
                        case 113:
                            mensaje = "Problemas con comentarios";
                            break;
                        case 156:
                            mensaje = "Error de sintaxis";
                            break;
                        case 2627:
                            mensaje = "Usuario ya existente";
                            break;
                        case 8152:
                            mensaje = "Longitud del dato sobre pasado";
                            break;
                        default:
                            mensaje = errorProducido.ToString();
                            break;
                    }

                    MessageBox.Show("Error con la base de datos: " + mensaje);
                    return -1;
                }
            }
        }

        public static Boolean InicioDeSesionCoordinador(int NumeroPersonal, String IdentificadorPersonal)
        {
            Boolean Validacion = false;
            ConexionBaseDeDatos dbManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = dbManager.ObtenerConexion())
            {
                conexion.Open();
                using (SqlCommand command = new SqlCommand("Select Validacion from Coordinador where IDCoordinador=@IDCoordinador AND NumeroPersonal=@NumeroPersonal", conexion))
                {
                    command.Parameters.Add(new SqlParameter("IDCoordinador", IdentificadorPersonal));
                    command.Parameters.Add(new SqlParameter("NumeroPersonal", NumeroPersonal));
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Validacion = reader.GetBoolean(0);
                    }
                    dbManager.CerrarConexion();
                    return Validacion;
                }
                
            }

        }

        public Coordinador RecuperarPorNombre(string nombre)
        {
            throw new NotImplementedException();
        }

        public Coordinador RecuperarPorApellidoPaterno(string apellidoPaterno)
        {
            throw new NotImplementedException();
        }

        public Coordinador RecuperarPorApellidoMaterno(string apellidoMaterno)
        {
            throw new NotImplementedException();
        }

        public Coordinador RecuperarPorCorreoElectronico(string correoElectronico)
        {
            throw new NotImplementedException();
        }
        public Coordinador RecuperarPorBloque(string bloque)
        {
            throw new NotImplementedException();
        }

        public Coordinador RecuperarPorNumeroPersonal(int numeroPersonal)
        {
            throw new NotImplementedException();
        }

        public List<Coordinador> GetCoordinador(string criterio)
        {
            throw new NotImplementedException();
        }
    }
}
