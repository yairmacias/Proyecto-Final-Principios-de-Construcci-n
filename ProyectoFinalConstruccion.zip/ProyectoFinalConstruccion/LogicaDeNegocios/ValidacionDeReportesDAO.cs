﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using BaseDeDatos;
using LogicaDeNegocios;
namespace LogicaDeNegocios
{
    class ValidacionDeReportesDAO
    {

        public static List<DataTable> ConsultarAlumnoEncargado()
        {
            List<DataTable> arregloTablas = new List<DataTable>();
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            DataTable dt1 = new DataTable();
            DataTable dt2 = new DataTable();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {
                try
                {


                    SqlCommand command = new SqlCommand("ConsultaEncargado", conexion);
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter(command);
                    conexion.Open();
                    da.Fill(dt1);
                    arregloTablas.Add(dt1);

                    command = new SqlCommand("ConsultarAlumno", conexion);
                    da = new SqlDataAdapter(command);
                    da.Fill(dt2);
                    arregloTablas.Add(dt2);

                    return arregloTablas;

                }
                catch (Exception ExcepcionGenerica)
                {
                    return arregloTablas;
                    MessageBox.Show(ExcepcionGenerica.ToString());

                }


            }
        }
        public static Boolean ActualizarReporte(List<String> matriculas)
        {
            List<int> respuestas = new List<int>();
            ConexionBaseDeDatos DBManager = new ConexionBaseDeDatos();
            using (SqlConnection conexion = DBManager.ObtenerConexion())
            {

                try
                {
                    conexion.Open();

                    for (int i = 0; i < matriculas.Count; i++)
                    {

                        SqlCommand command = new SqlCommand("update Alumno set Validado = 1 where Matricula=@Matricula", conexion);
                        command.Parameters.AddWithValue("@Matricula", matriculas[i]);

                        respuestas.Add(command.ExecuteNonQuery());
                    }

                    conexion.Close();

                    Boolean bandera = true;
                    foreach (int a in respuestas)
                    {
                        if (a == 0)
                        {
                            bandera = false;
                            break;
                        }
                    }

                    return bandera;
                }

                catch (Exception ExcepcionGenerica)
                {
                    System.Windows.MessageBox.Show(ExcepcionGenerica.ToString());
                    return false;
                }
            }
        }
    }
}
